//
//  CommentModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/20.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommentViewModel.h"

@interface CommentViewModel()

@property (nonatomic) NSInteger trendCount;

@end

@implementation CommentViewModel

#pragma mark - 懒加载
- (NSMutableArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
- (NSInteger)rowNumber {
    return _dataArr.count;
}


/** 作者头像 */
- (NSURL *)iconBy:(BmobUser *)user {
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[user objectForKey:@"userIcon"]];
    return [NSURL URLWithString:imageURL];
}
/** 作者昵称 */
- (NSString *)userNameBy:(BmobUser *)user {
    return [user objectForKey:@"username"];
}



/** 帖子标题 */
- (NSString *)titleByObject:(BmobObject *)post {
    return [post objectForKey:@"title"];
}
/** 帖子内容 */
- (NSString *)contentByObject:(BmobObject *)post {
    return [post objectForKey:@"content"];
}
/** 图片地址 */
- (NSArray *)allImagesByObject:(BmobObject *)post {
    NSMutableArray *allPic = [NSMutableArray array];
    NSString *url = [post objectForKey:@"imageUrl"];
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",url];
    [allPic addObject:[NSURL URLWithString:imageURL]];
    return [allPic copy];
}
/** 图片高度 */
- (NSInteger)imageHightByObject:(BmobObject *)post {
    NSString *url = [post objectForKey:@"imageUrl"];
    if (url.length < 10) {
        return 0;
    }
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",url];
    UIImageView *imageView = [[UIImageView alloc] init];
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:imageURL]];
    CGSize imageSize = imageView.image.size;
    CGFloat bili = imageSize.height * 1.0 / imageSize.width;
    
    return (kWindowW - 20) * bili;
}

/** 帖子发表时间 */
- (NSString *)dateByObject:(BmobObject *)post {
    NSDate *date = post.createdAt;
    NSInteger t = 0 - [date timeIntervalSinceNow];
    NSInteger dayTime = 3600 * 24;
    NSString *createDate = [NSString stringWithFormat:@"%ld秒前",t];
    if (t > 60 && t < 3600) {
        createDate = [NSString stringWithFormat:@"%ld分钟前",t/60];
    }else if (t > 3600 && t < dayTime) {
        createDate = [NSString stringWithFormat:@"%ld小时前",t/3600];
    }else if (t > dayTime) {
        createDate = [NSString stringWithFormat:@"%ld天前",t/dayTime];
    }
    
    return createDate;
}


/** 点赞数 */
- (NSInteger)likeCountByObject:(BmobObject *)post {

    BmobQuery *bquery = [BmobQuery queryWithClassName:@"_User"];
    
    //需要查询的列
    static NSInteger count = 0;
    NSString *sectionName = @"";
    switch (self.sectionType) {
        case ClickTypeMix: {
            sectionName = @"MixPost";
            break;
        }
        case ClickTypeMan: {
            sectionName = @"BoyPost";
            break;
        }
        case ClickTypeWomen: {
            sectionName = @"GirlPost";
            break;
        }
        default: {
            break;
        }
    }
    
    BmobObject *postd = [BmobObject objectWithoutDatatWithClassName:sectionName objectId:post.objectId];
    [bquery whereObjectKey:@"likes" relatedTo:postd];
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error) {
            [self showSuccessMsg:@"出错啦"];
            for (BmobObject *obj in array) {
                if (obj == [BmobUser getCurrentUser]) {
                    self.isHadLike = YES;
                    break;
                }
            }
        } else {
            count = array.count;
        }
    }];
    return count;
    
}
/** 评论数 */
- (NSInteger)commentCountByObject:(BmobObject *)post {
    
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"Comment"];
    [bquery whereKey:@"postSoure" equalTo:post.objectId];
    [bquery countObjectsInBackgroundWithBlock:^(int number,NSError  *error){
        self.trendCount = number;
    }];
    return self.trendCount;
}



/** 评论人头像 */
- (NSURL *)commentUserIconForRow:(NSInteger)row {
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[[self authorForRow:row] objectForKey:@"userIcon"]];
    return [NSURL URLWithString:imageURL];
}
/** 评论人昵称 */
- (NSString *)commentUsernameForRow:(NSInteger)row {
    return [[self authorForRow:row] objectForKey:@"username"];
}


/** 评论时间 */
- (NSString *)commentDataForRow:(NSInteger)row {
    NSDate *date = [self commentModelForRow:row].createdAt;
    NSInteger t = 0 - [date timeIntervalSinceNow];
    NSInteger dayTime = 3600 * 24;
    NSString *createDate = [NSString stringWithFormat:@"%ld秒前",t];
    if (t > 60 && t < 3600) {
        createDate = [NSString stringWithFormat:@"%ld分钟前",t/60];
    }else if (t > 3600 && t < dayTime) {
        createDate = [NSString stringWithFormat:@"%ld小时前",t/3600];
    }else if (t > dayTime) {
        createDate = [NSString stringWithFormat:@"%ld天前",t/dayTime];
    }
    return createDate;
}
/** 评论内容 */
- (NSString *)commentContentForRow:(NSInteger)row {
    return [[self commentModelForRow:row] objectForKey:@"commentContent"];
}
/** 回复用户的用户名 */
- (NSString *)answerOneContentForRow:(NSInteger)row {
    return @"猪猪";
}
/** 是否是回复某用户的评论 */
- (BOOL)isAnswerCommentForRow:(NSInteger)row {
    if (row % 2 == 0) {
        return YES;
    }else
        return NO;
}

- (void)getDataWithPost:(BmobObject *)post CompletionHandle:(void(^)(NSError *error))completionHandle {
    BmobQuery *comment = [BmobQuery queryWithClassName:@"Comment"];
    comment.limit = 10;
    comment.skip = self.page;
    [comment orderByAscending:@"createdAt"];
    // 优先从本地缓存获取数据，假如没有数据才从网络下载
    comment.cachePolicy = kBmobCachePolicyNetworkElseCache;
    // 包含评论人的数据
    [comment includeKey:@"author"];
    // 查找数据
    [comment whereKey:@"postSoure" equalTo:post.objectId];
    [comment findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (_page == 0) {
            [self.dataArr removeAllObjects];
        }else {
            if (array.count < 1) {
                [self showErrorMsg:@"没有更多的评论"];
            }
        }
        [self.dataArr addObjectsFromArray:array];
        completionHandle(error);
        
    }];
}

/** 评论信息 */
- (BmobObject *)commentModelForRow:(NSInteger)row {
    return self.dataArr[row];
}

/** 评论人信息 */
- (BmobUser *)authorForRow:(NSInteger)row {
    return [[self commentModelForRow:row] objectForKey:@"author"];
}

/** 刷新评论数据 */
- (void)refreshCommentDataWithPost:(BmobObject *)post CompletionHandle:(void(^)(NSError *error))completionHandle {
    self.page = 0;
    [self getDataWithPost:post CompletionHandle:completionHandle];
}
/** 更多评论数据 */
- (void)getMoreCommentDataWithPost:(BmobObject *)post CompletionHandle:(void(^)(NSError *error))completionHandle {
    self.page += 10;
    [self getDataWithPost:post CompletionHandle:completionHandle];
}

@end
