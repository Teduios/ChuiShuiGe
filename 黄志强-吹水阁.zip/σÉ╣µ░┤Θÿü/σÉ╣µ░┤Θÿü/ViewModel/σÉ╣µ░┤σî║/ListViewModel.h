//
//  ListViewModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/13.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, ListType) {
    ListTypeNormal,     // 正常情况
    ListTypeCondition   // 条件查询
};
@interface ListViewModel : NSObject

/** 帖子的数量 */
@property (nonatomic) NSInteger rowNumber;
/** 存储数据 */
@property (strong, nonatomic) NSMutableArray *dataArr;
/** 数据量 */
@property (nonatomic) NSInteger page;
/** 最大数据量 */
@property (nonatomic) int maxPage;
/** 类型 */
@property (nonatomic) ListType type;
/** 条件 */
@property (strong, nonatomic) NSString *key;
@property (strong, nonatomic) id value;

/** 类型 */
@property (nonatomic) ClickType sectionType;


/** 用户头像 */
- (NSURL *)userIconForRow:(NSInteger)row;
/** 用户名 */
- (NSString *)userNikeNameForRow:(NSInteger)row;
/** 创建时间 */
- (NSString *)createTimeForRow:(NSInteger)row;
/** 内容标题 */
- (NSString *)titleForRow:(NSInteger)row;
/** 内容 */
- (NSString *)contentForRow:(NSInteger)row;
/** 图片 */
- (NSArray *)allImagesForRow:(NSInteger)row;
/** 点赞数 */
- (NSString *)likeCountForRow:(NSInteger)row;
/** 评论数 */
- (NSString *)commentCountForRow:(NSInteger)row;


//- (NSURL *)imageURLForRow:(NSInteger)row;

/** 是否有照片 */
- (BOOL)isHadPicForRow:(NSInteger)row;
/** 是否是最大数据量 */
@property(nonatomic, getter=isHasMore) BOOL hasMore;

/** 作者信息 */
- (BmobUser *)authorForRow:(NSInteger)row;

/** 帖子信息 */
- (BmobObject *)postModelForRow:(NSInteger)row;


/**
 *  获取数据
 */
- (void)refreshDataCompletionHandle:(void(^)(NSError *error))completionHandle;

- (void)getMoreDataCompletionHandle:(void(^)(NSError *error))completionHandle;



@end
