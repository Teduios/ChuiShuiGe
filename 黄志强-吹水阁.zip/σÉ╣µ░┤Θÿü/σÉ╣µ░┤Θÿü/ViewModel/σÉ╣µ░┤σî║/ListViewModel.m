//
//  ListViewModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/13.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "ListViewModel.h"

@interface ListViewModel()

@property (copy, nonatomic) NSString *trendCount;

@end

@implementation ListViewModel
#pragma mark - 懒加载
- (NSMutableArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (int)maxPage {
    NSString *sectionName = @"";
    switch (self.sectionType) {
        case ClickTypeMix: {
            sectionName = @"MixPost";
            break;
        }
        case ClickTypeMan: {
            sectionName = @"BoyPost";
            break;
        }
        case ClickTypeWomen: {
            sectionName = @"GirlPost";
            break;
        }
        default: {
            break;
        }
    }
    BmobQuery *bquery = [BmobQuery queryWithClassName:sectionName];
    static int c = 0;
    [bquery countObjectsInBackgroundWithBlock:^(int number,NSError  *error){
        c = number;
    }];
    return c;
}

- (BOOL)isHasMore{
    return self.maxPage > self.page;
}



/** 用户头像 */
- (NSURL *)userIconForRow:(NSInteger)row {
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[[self authorForRow:row] objectForKey:@"userIcon"]];
    return [NSURL URLWithString:imageURL];
}
/** 用户名 */
- (NSString *)userNikeNameForRow:(NSInteger)row {
    return [[self authorForRow:row] objectForKey:@"username"];
}

/** 创建时间 */
- (NSString *)createTimeForRow:(NSInteger)row {
    return [[self postModelForRow:row] objectForKey:@"createdAt"];
}
/** 内容标题 */
- (NSString *)titleForRow:(NSInteger)row {
    return [[self postModelForRow:row] objectForKey:@"title"];
}
/** 内容 */
- (NSString *)contentForRow:(NSInteger)row {
    return [[self postModelForRow:row] objectForKey:@"content"];
}
/** 图片 */
- (NSArray *)allImagesForRow:(NSInteger)row {
    NSMutableArray *allPic = [NSMutableArray array];
    NSString *url = [[self postModelForRow:row] objectForKey:@"imageUrl"];
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",url];
    [allPic addObject:[NSURL URLWithString:imageURL]];
    return [allPic copy];
    
}

/** 是否有照片 */
- (BOOL)isHadPicForRow:(NSInteger)row {
    NSString *imageString = [[self postModelForRow:row] objectForKey:@"imageUrl"];
    return imageString.length > 10 ? YES : NO;
}

/** 点赞数 */
- (NSString *)likeCountForRow:(NSInteger)row {
    
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"_User"];
    
    //需要查询的列
    static NSInteger count = 0;
    NSString *sectionName = @"";
    switch (self.sectionType) {
        case ClickTypeMix: {
            sectionName = @"MixPost";
            break;
        }
        case ClickTypeMan: {
            sectionName = @"BoyPost";
            break;
        }
        case ClickTypeWomen: {
            sectionName = @"GirlPost";
            break;
        }
        default: {
            break;
        }
    }
    
    BmobObject *postd = [BmobObject objectWithoutDatatWithClassName:sectionName objectId:[self postModelForRow:row].objectId];
    [bquery whereObjectKey:@"likes" relatedTo:postd];
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error) {
            [self showSuccessMsg:@"出错啦"];
        } else {
            count = array.count;
        }
    }];
    return [NSString stringWithFormat:@"%ld",count];
    
}
/** 评论数 */
- (NSString *)commentCountForRow:(NSInteger)row {
    
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"Comment"];
    [bquery whereKey:@"postSoure" equalTo:[self postModelForRow:row].objectId];
    [bquery countObjectsInBackgroundWithBlock:^(int number,NSError  *error){
        self.trendCount = [NSString stringWithFormat:@"%d",number];
    }];
    return self.trendCount;
}




#pragma mark - 获取数据
- (void)getDataCompletion:(void(^)(NSError *error))completionHandle {
    NSString *sectionName = @"";
    switch (self.sectionType) {
        case ClickTypeMix: {
            sectionName = @"MixPost";
            break;
        }
        case ClickTypeMan: {
            sectionName = @"BoyPost";
            break;
        }
        case ClickTypeWomen: {
            sectionName = @"GirlPost";
            break;
        }
        default: {
            break;
        }
    }
    BmobQuery *post = [BmobQuery queryWithClassName:sectionName];
    post.limit = 4;
    post.skip = self.page;
    [post orderByDescending:@"createdAt"];
    
    [post includeKey:@"author"];
    if (self.type == ListTypeCondition) {
        [post whereKey:self.key equalTo:self.value];
    }
    // 优先从本地缓存获取数据，假如没有数据才从网络下载
    post.cachePolicy = kBmobCachePolicyNetworkElseCache;
    // 查找数据
    [post findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (_page == 0) {
            [self.dataArr removeAllObjects];
        }
        if (array.count < 1) {
            [self showErrorMsg:@"没有更多数据"];
        }
        [self.dataArr addObjectsFromArray:array];
        completionHandle(error);
    }];
}

/** 帖子信息 */
- (BmobObject *)postModelForRow:(NSInteger)row {
    return self.dataArr[row];
}

/** 作者信息 */
- (BmobUser *)authorForRow:(NSInteger)row {
    return [[self postModelForRow:row] objectForKey:@"author"];
}

- (void)refreshDataCompletionHandle:(void(^)(NSError *error))completionHandle {
    self.page = 0;
    [self getDataCompletion:completionHandle];
}

- (void)getMoreDataCompletionHandle:(void(^)(NSError *error))completionHandle {
        self.page += 4;
        [self getDataCompletion:completionHandle];
    
}


@end
