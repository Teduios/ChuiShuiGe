//
//  CommentModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/20.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface CommentViewModel : NSObject

/** 评论数量 */
@property (nonatomic) NSInteger rowNumber;
/** 存储评论内容 */
@property (strong, nonatomic) NSMutableArray *dataArr;
/** 数据量 */
@property (nonatomic) NSInteger page;
/** 最大数据量 */
@property (nonatomic) int maxPage;

/** 作者头像 */
- (NSURL *)iconBy:(BmobUser *)user;
/** 作者昵称 */
- (NSString *)userNameBy:(BmobUser *)user;
/** 类型 */
@property (nonatomic) ClickType sectionType;


/** 帖子标题 */
- (NSString *)titleByObject:(BmobObject *)post;
/** 帖子内容 */
- (NSString *)contentByObject:(BmobObject *)post;
/** 图片地址 */
- (NSArray *)allImagesByObject:(BmobObject *)post;
/** 图片高度 */
- (NSInteger)imageHightByObject:(BmobObject *)post;
/** 点赞数 */
- (NSInteger)likeCountByObject:(BmobObject *)post;
/** 评论数 */
- (NSInteger)commentCountByObject:(BmobObject *)post;
/** 帖子发表时间 */
- (NSString *)dateByObject:(BmobObject *)post;
/** 当前登录的用户是否已经点赞 */
@property (nonatomic) BOOL isHadLike;

/** 评论人头像 */
- (NSURL *)commentUserIconForRow:(NSInteger)row;
/** 评论人昵称 */
- (NSString *)commentUsernameForRow:(NSInteger)row;
/** 评论时间 */
- (NSString *)commentDataForRow:(NSInteger)row;
/** 评论内容 */
- (NSString *)commentContentForRow:(NSInteger)row;
/** 回复用户的用户名 */
- (NSString *)answerOneContentForRow:(NSInteger)row;
/** 是否是回复某用户的评论 */
- (BOOL)isAnswerCommentForRow:(NSInteger)row;

/** 刷新评论数据 */
- (void)refreshCommentDataWithPost:(BmobObject *)post CompletionHandle:(void(^)(NSError *error))completionHandle;
/** 更多评论数据 */
- (void)getMoreCommentDataWithPost:(BmobObject *)post CompletionHandle:(void(^)(NSError *error))completionHandle;



@end
