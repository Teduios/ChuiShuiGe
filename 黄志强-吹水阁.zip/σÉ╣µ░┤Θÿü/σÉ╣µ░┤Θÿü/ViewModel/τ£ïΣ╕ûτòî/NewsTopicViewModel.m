//
//  NewsTopicViewModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/26.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsTopicViewModel.h"


@implementation NewsTopicViewModel

#pragma mark - 懒加载
- (NSMutableArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (NSArray *)headerArr {
    if (_headerArr == nil) {
        _headerArr = [[NSArray alloc] init];
    }
    return _headerArr;
}

- (NSInteger)sectionNumber {
    if (self.dataArr.count < 1) {
        return 0;
    }else {
            return self.dataArr.count-3;
    }
    
}



/** 导读内容 */
- (NSString *)intro {
    return [self subjectsModelForSection:1].content.intro;
}
/** 头部图片组 */
- (NSArray *)headerImages {
    NSInteger count = self.headerArr.count;
    if (self.dataArr.count < 1) {
        return @[];
    }else {
        NSMutableArray *arr = [NSMutableArray array];
        for (int i = 0; i < count; i++) {
            NSURL *url = [NSURL URLWithString:[self podItemsModelWithSection:2 ForRow:i].thumbnail];
            [arr addObject:url];
        }
        return [arr copy];
    }
}
/** 头部标题 */
- (NSString *)headerTitleForRow:(NSInteger)row {
    return [self podItemsModelWithSection:2 ForRow:row].title;
}
/** 头部图片链接 */
- (NSString *)headerURLForRow:(NSInteger)row {
    NSArray *arr = [self podItemsModelWithSection:2 ForRow:row].links;
    PodItemsLinkModel *linkModel = arr[0];
    return linkModel.url;
}
/** 是否有头部图片 */
- (BOOL)hasHeaderImage {
    return [[self subjectsModelForSection:2].view isEqualToString:@"slider"];
}



/** 分区头名字 */
- (NSString *)headerTitleForSection:(NSInteger)section {
    return [self subjectsModelForSection:section+3].title;
}

/** 标题 */
- (NSString *)titleWithSection:(NSInteger)section ForRow:(NSInteger)row {
    NSString *str = [self podItemsModelWithSectionInRow:section ForRow:row].title;
    return str;
}
/** 时间 */
- (NSString *)dateWithSection:(NSInteger)section ForRow:(NSInteger)row {
    if ([self podItemsModelWithSectionInRow:section ForRow:row].updateTime.length < 11) {
        return @"";
    }
    return [[self podItemsModelWithSectionInRow:section ForRow:row].updateTime substringFromIndex:11];
}
/** 图片 */
- (NSURL *)imageWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [NSURL URLWithString:[self podItemsModelWithSectionInRow:section ForRow:row].thumbnail];
}
/** 是否是照片组 */
- (BOOL)isImagesWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return NO;
}
/** 照片组 */
- (NSArray *)imagesWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return @[];
}
/** 评论数 */
- (NSString *)commentsForRow:(NSInteger)row {
    return @"";
}
/** 新闻的类型 */
- (NSString *)typeWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [self podItemsModelWithSectionInRow:section ForRow:row].style;
}

/** 时政页面是否有照片 */
- (BOOL)isHadImageWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [self podItemsModelWithSectionInRow:section ForRow:row].thumbnail.length == 0 ? NO : YES;
}
/** 详情页地址 */
- (NSString *)detailURLWithSection:(NSInteger)section ForRow:(NSInteger)row {
    NSArray *link = [self podItemsModelWithSectionInRow:section ForRow:row].links;
    PodItemsLinkModel *linkModel = link[0];
    return linkModel.url;
}

/** 是否有视频 */
- (BOOL)isHadVideoWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [self podItemsModelWithSectionInRow:section ForRow:row].hasVideo;
}
/** 是否是图片浏览模式 */
- (BOOL)isHadSlideWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [self podItemsModelWithSectionInRow:section ForRow:row].hasSlide;
}


/** 获取数据 */

- (BodySubjectsModel *)subjectsModelForSection:(NSInteger)section {
    return self.dataArr[section];
}

// 用于获取分区数据

- (BodySubjectsModel *)subjectsModelForSectionInRow:(NSInteger)section {
        return self.dataArr[section+3];
}

- (PodItemsModel *)podItemsModelWithSection:(NSInteger)section ForRow:(NSInteger)row {
    return [self subjectsModelForSection:section].podItems[row];
}

- (PodItemsModel *)podItemsModelWithSectionInRow:(NSInteger)section ForRow:(NSInteger)row {
    return [self subjectsModelForSectionInRow:section].podItems[row];
}


- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle {
    [NewsNetworkManager getNewsTopicForPath:self.path completionHandle:^(TopicModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.body.subjects];
        
        if ([[self subjectsModelForSection:2].view isEqualToString:@"slider"]) {
            self.headerArr = [self subjectsModelForSection:2].podItems;
        }
        completionHandle(error);
    }];
}


@end
