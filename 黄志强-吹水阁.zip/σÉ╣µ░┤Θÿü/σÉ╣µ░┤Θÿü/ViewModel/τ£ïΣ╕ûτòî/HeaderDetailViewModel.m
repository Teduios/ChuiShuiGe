//
//  HeaderDetailViewModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "HeaderDetailViewModel.h"
#import "NewsNetworkManager.h"

@implementation HeaderDetailViewModel

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (NSArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [NSArray array];
    }
    return _dataArr;
}

/** 图片数组 */
- (NSArray *)allImagesArr {
    NSMutableArray *arr = [NSMutableArray array];
    NSInteger count = self.dataArr.count;
    for (int i = 0; i < count; i++) {
        Slides *slide = self.dataArr[i];
        NSURL *imageURL = [NSURL URLWithString:slide.image];
        [arr addObject:imageURL];
    }
    return [arr copy];
}
/** 文字描述数组 */
- (NSArray *)allTextsArr {
    NSMutableArray *arr = [NSMutableArray array];
    NSInteger count = self.dataArr.count;
    for (int i = 0; i < count; i++) {
        Slides *slide = self.dataArr[i];
        NSString *descString = slide.desc;
        [arr addObject:descString];
    }
    return [arr copy];
}


/** 描述 */
- (NSString *)descriptionForRow:(NSInteger)row {
    return [self slidesModelForRow:row].desc;
}

- (Slides *)slidesModelForRow:(NSInteger)row {
    return self.dataArr[row];
}

/** 获取数据 */
- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle {
    [NewsNetworkManager getHeaderDetailForPath:self.path completionHandle:^(HeaderDetailModel *model, NSError *error) {
        self.dataArr = model.body.slides;
        self.title = model.body.title;
        completionHandle(error);
    }];
}

- (instancetype)initWithPath:(NSString *)path {
    if (self = [super init]) {
        [NewsNetworkManager getHeaderDetailForPath:path completionHandle:^(HeaderDetailModel *model, NSError *error) {
            self.dataArr = model.body.slides;
            self.title = model.body.title;
        }];
    }
    return self;
}

@end
