//
//  NewsDetailViewModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/25.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsDetailViewModel : NSObject

// 地址
@property (strong, nonatomic) NSString *path;

// 返回内容
- (NSString *)content;
// 返回标题
- (NSString *)title;
// 返回时间
- (NSString *)date;
// 返回网页地址
- (NSURL *)wapURL;

// 获取数据
- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle;

@end
