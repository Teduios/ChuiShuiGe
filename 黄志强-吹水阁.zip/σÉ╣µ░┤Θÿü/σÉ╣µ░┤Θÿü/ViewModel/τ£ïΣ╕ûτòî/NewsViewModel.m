//
//  NewsViewModel.m
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsViewModel.h"
#import "NewsModel.h"


@implementation NewsViewModel

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (NSMutableArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (NSArray *)headerDataArr {
    if (_headerDataArr == nil) {
        _headerDataArr = [NSArray array];
    }
    return _headerDataArr;
}

/** 标题 */
- (NSString *)titleForRow:(NSInteger)row {
    return [self itemModelForRow:row].title;
}
/** 时间 */
- (NSString *)dateForRow:(NSInteger)row {
    if ([self itemModelForRow:row].updateTime.length < 11) {
        return @"";
    }
    return [[self itemModelForRow:row].updateTime substringFromIndex:11];
}
/** 图片 */
- (NSURL *)imageForRow:(NSInteger)row {
    return [NSURL URLWithString:[self itemModelForRow:row].thumbnail];
}
/** 是否是照片组 */
- (BOOL)isImagesForRow:(NSInteger)row {
    NSArray *arr = [self itemModelForRow:row].style.images;
    if (arr.count < 2) {
        return NO;
    }else {
        return YES;
    }
//    return [[self itemModelForRow:row].type isEqualToString:@"slide"] ? YES : NO;
}
/** 照片组 */
- (NSArray *)imagesForRow:(NSInteger)row {
    NSArray *arr = [self itemModelForRow:row].style.images;
    NSMutableArray *imageArr = [NSMutableArray array];
    NSInteger count = arr.count;
    if (count < 3) {
        return @[@"",@"",@""];
    }
    for (int i = 0; i < count; i++) {
        NSURL *url = [NSURL URLWithString:arr[i]];
        [imageArr addObject:url];
    }
    return [imageArr copy];
}
/** 评论数 */
- (NSString *)commentsForRow:(NSInteger)row {
    return [self itemModelForRow:row].comments;
}

/** 时政页面是否有照片 */
- (BOOL)isHadImageForRow:(NSInteger)row {
    return [self itemModelForRow:row].thumbnail.length == 0 ? NO : YES;
}

/** 详情页地址 */
- (NSString *)detailURLForRow:(NSInteger)row {
    return [self itemModelForRow:row].link.url;
}

- (NSString *)typeForRow:(NSInteger)row {
    return [self itemModelForRow:row].type;
}



/** 头部图片组 */
- (NSArray *)headerImages {
    NSMutableArray *arr = [NSMutableArray array];
    NSInteger count = self.headerDataArr.count;
    for (int i = 0; i < count; i++) {
        NSURL *url = [NSURL URLWithString:[self headerItemModelForRow:i].thumbnail];
        [arr addObject:url];
    }
    return [arr copy];
}
/** 头部标题 */
- (NSString *)headerTitleForRow:(NSInteger)row {
    return [self headerItemModelForRow:row].title;
}
/** 头部图片链接 */
- (NSString *)headerURLForRow:(NSInteger)row {
    return [self headerItemModelForRow:row].link.url;
}

/** 是否有头部图片 */
- (BOOL)hasHeaderImage {
    NSInteger c = self.headerDataArr.count;
    return  c > 0;
}





/**
 *  获取数据
 */

- (Item *)itemModelForRow:(NSInteger)row {
    return self.dataArr[row];
}

- (Item *)headerItemModelForRow:(NSInteger)row {
    return self.headerDataArr[row];
}


- (void)getDataCompletionhandle:(void (^)(NSError *error))completionHandle {
    [NewsNetworkManager getNewWithType:self.type andPage:_page completionHandle:^(NewsModel *model, NSError *error) {
        completionHandle(error);
        if (self.page == 1) {
            [self.dataArr removeAllObjects];
        }
        if (model.esArray.count == 2) {
            self.headerDataArr = model.esArray[1].item;
        }
        [self.dataArr addObjectsFromArray:model.esArray[0].item];
    }];
}


- (void)refreshDataCompletionHandle:(void(^)(NSError *error))completionHandle {
    self.page = 1;
    [self getDataCompletionhandle:completionHandle];
}

- (void)getMoreDataCompletionhandle:(void(^)(NSError *error))completionHandle {
    _page++;
    [self getDataCompletionhandle:completionHandle];
}

@end
