//
//  HeaderDetailViewModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeaderDetailViewModel : NSObject

/** 数据量 */
@property (strong, nonatomic) NSArray *dataArr;
/** 总页数 */
@property (nonatomic) NSInteger rowNumber;
/** 标题 */
@property (strong, nonatomic) NSString *title;
/** 地址 */
@property (strong, nonatomic) NSString *path;

/** 图片数组 */
- (NSArray *)allImagesArr;
/** 文字描述数组 */
- (NSArray *)allTextsArr;
/** 获取数据 */
- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle;

- (instancetype)initWithPath:(NSString *)path;


@end
