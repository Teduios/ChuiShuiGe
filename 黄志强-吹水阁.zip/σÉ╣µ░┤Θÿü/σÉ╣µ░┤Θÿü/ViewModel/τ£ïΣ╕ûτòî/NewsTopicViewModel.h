//
//  NewsTopicViewModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/26.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NewsNetworkManager.h"

@interface NewsTopicViewModel : NSObject

/** 数据地址 */
@property (strong, nonatomic) NSString *path;
/** 分区数 */
@property (nonatomic) NSInteger sectionNumber;
/** 数据存储 */
@property (strong, nonatomic) NSMutableArray *dataArr;
/** 头部滚动视图 */
@property (strong, nonatomic) NSArray *headerArr;

/** 导读内容 */
- (NSString *)intro;
/** 头部图片组 */
- (NSArray *)headerImages;
/** 头部标题 */
- (NSString *)headerTitleForRow:(NSInteger)row;
/** 头部图片链接 */
- (NSString *)headerURLForRow:(NSInteger)row;
/** 是否有头部图片 */
- (BOOL)hasHeaderImage;



/** 分区头名字 */
- (NSString *)headerTitleForSection:(NSInteger)section;

/** 标题 */
- (NSString *)titleWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 时间 */
- (NSString *)dateWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 图片 */
- (NSURL *)imageWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 是否是照片组 */
- (BOOL)isImagesWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 照片组 */
- (NSArray *)imagesWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 评论数 */
- (NSString *)commentsForRow:(NSInteger)row;
/** 新闻的类型 */
- (NSString *)typeWithSection:(NSInteger)section ForRow:(NSInteger)row;


/** 时政页面是否有照片 */
- (BOOL)isHadImageWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 详情页地址 */
- (NSString *)detailURLWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 是否有视频 */
- (BOOL)isHadVideoWithSection:(NSInteger)section ForRow:(NSInteger)row;
/** 是否是图片浏览模式 */
- (BOOL)isHadSlideWithSection:(NSInteger)section ForRow:(NSInteger)row;

// 用于获取分区数据

- (BodySubjectsModel *)subjectsModelForSectionInRow:(NSInteger)section;

/** 获取数据 */

- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle;


@end
