//
//  NewsViewModel.h
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NewsNetworkManager.h"

@interface NewsViewModel : NSObject

/** 行数 */
@property (nonatomic) NSInteger rowNumber;

/** 存储数据 */
@property (strong, nonatomic) NSMutableArray *dataArr;

/** 头部数据 */
@property (strong, nonatomic) NSArray *headerDataArr;

/** 类型 */
@property (nonatomic) NewsType type;

/** 页数 */
@property (nonatomic) NSInteger page;


/** 标题 */
- (NSString *)titleForRow:(NSInteger)row;
/** 时间 */
- (NSString *)dateForRow:(NSInteger)row;
/** 图片 */
- (NSURL *)imageForRow:(NSInteger)row;
/** 是否是照片组 */
- (BOOL)isImagesForRow:(NSInteger)row;
/** 照片组 */
- (NSArray *)imagesForRow:(NSInteger)row;
/** 评论数 */
- (NSString *)commentsForRow:(NSInteger)row;
/** 新闻的类型 */
- (NSString *)typeForRow:(NSInteger)row;


/** 时政页面是否有照片 */
- (BOOL)isHadImageForRow:(NSInteger)row;
/** 详情页地址 */
- (NSString *)detailURLForRow:(NSInteger)row;

/** 头部图片组 */
- (NSArray *)headerImages;
/** 头部标题 */
- (NSString *)headerTitleForRow:(NSInteger)row;
/** 头部图片链接 */
- (NSString *)headerURLForRow:(NSInteger)row;
/** 是否有头部图片 */
- (BOOL)hasHeaderImage;



/**
 *  获取数据
 */
- (void)refreshDataCompletionHandle:(void(^)(NSError *error))completionHandle;

- (void)getMoreDataCompletionhandle:(void(^)(NSError *error))completionHandle;

@end
