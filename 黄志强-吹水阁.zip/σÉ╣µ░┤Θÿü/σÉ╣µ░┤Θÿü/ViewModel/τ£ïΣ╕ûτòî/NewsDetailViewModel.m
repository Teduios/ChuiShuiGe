//
//  NewsDetailViewModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/25.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsDetailViewModel.h"
#import "NewsNetworkManager.h"

@interface NewsDetailViewModel()

@property (strong, nonatomic) NBody *body;

@end

@implementation NewsDetailViewModel
- (NBody *)body {
    if (_body == nil) {
        _body = [[NBody alloc] init];
    }
    return _body;
}

// 返回内容
- (NSString *)content {
    NSString *headers = @"";
    if ([self.body.hasVideo isEqualToString:@"Y"] || [self.body.hasVideo isEqualToString:@"true"]) {
        headers = [NSString stringWithFormat:@"<head><style>img{width:320px !important;}</style></head><h2>%@</h2><p style=\"font-size:13px;color:3C3C3C;\">%@</p><video width=\"%.f\" height=\"280\" controls=\"controls\" autoplay=\"autoplay\"><source src=\"%@\" type=\"video/mp4\">Your browser does not support the video tag.</video>",self.body.title,self.body.editTime,kWindowW-16,self.body.videoSrc];
    }else {
        headers = [NSString stringWithFormat:@"<head><style>img{width:320px !important;}</style></head><h2>%@</h2><p style=\"font-size:13px;color:3C3C3C;\">%@</p>",self.body.title,self.body.editTime];
    }
    
    if (self.body.text == nil) {
        return @"";
    }else {
         return [headers stringByAppendingString:self.body.text];
    }
   
}
// 返回标题
- (NSString *)title {
    return self.body.title;
}
// 返回时间
- (NSString *)date {
    return self.body.editTime;
}\
// 返回网页地址
- (NSURL *)wapURL {
    return [NSURL URLWithString:self.body.wapurl];
}


// 获取数据
- (void)getDataCompletionHandle:(void(^)(NSError *error))completionHandle {
    [NewsNetworkManager getNewsDetailForPath:self.path completionHandle:^(NewsDetailModel *model, NSError *error) {
        self.body = model.body;
        completionHandle(error);
    }];
}

@end
