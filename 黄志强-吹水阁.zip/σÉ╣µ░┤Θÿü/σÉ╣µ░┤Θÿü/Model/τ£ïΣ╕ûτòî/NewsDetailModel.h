//
//  NewsDetailModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/25.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NMeta,NBody,Img,Videos,Video,Normal,Hd,Thumbnailsize;
@interface NewsDetailModel : NSObject


@property (nonatomic, strong) NMeta *meta;

@property (nonatomic, strong) NBody *body;




@end


@interface NMeta : NSObject

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *cls;

@property (nonatomic, assign) NSInteger o;

@property (nonatomic, copy) NSString *type;

@end

@interface NBody : NSObject

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *programNo;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *videoSrc;

@property (nonatomic, strong) NSArray<Img *> *img;

@property (nonatomic, copy) NSString *shareurl;

@property (nonatomic, copy) NSString *wwwurl;

@property (nonatomic, copy) NSString *channel;

@property (nonatomic, copy) NSString *hasVideo;

@property (nonatomic, copy) NSString *commentType;

@property (nonatomic, copy) NSString *cate;

@property (nonatomic, copy) NSString *program;

@property (nonatomic, copy) NSString *commentCount;

@property (nonatomic, copy) NSString *editTime;

@property (nonatomic, copy) NSString *sologan;

@property (nonatomic, copy) NSString *introduction;

@property (nonatomic, copy) NSString *commentsUrl;

@property (nonatomic, copy) NSString *text;

@property (nonatomic, copy) NSString *videoPoster;

@property (nonatomic, strong) NSArray<Videos *> *videos;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *wapurl;

@end

@interface Img : NSObject

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *size;

@end

@interface Videos : NSObject

@property (nonatomic, copy) NSString *guid;

@property (nonatomic, strong) Thumbnailsize *thumbnailSize;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) Video *video;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, copy) NSString *duration;

@end

@interface Video : NSObject

@property (nonatomic, strong) Normal *Normal;

@property (nonatomic, strong) Hd *HD;

@end

@interface Normal : NSObject

@property (nonatomic, copy) NSString *src;

@end

@interface Hd : NSObject

@property (nonatomic, copy) NSString *src;

@end

@interface Thumbnailsize : NSObject

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *height;

@end

