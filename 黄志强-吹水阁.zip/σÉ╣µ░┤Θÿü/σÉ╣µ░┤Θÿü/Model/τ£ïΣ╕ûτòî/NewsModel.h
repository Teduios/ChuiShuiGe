//
//  NewsModel.h
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Esarray,Item,Link,Sty;
@interface NewsModel : NSObject


@property (nonatomic, strong) NSArray<Esarray *> *esArray;


@end
@interface Esarray : NSObject

@property (nonatomic, strong) NSArray<Item *> *item;

@property (nonatomic, assign) NSInteger expiredTime;

@property (nonatomic, copy) NSString *listId;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger currentPage;

@property (nonatomic, assign) NSInteger totalPage;

@end

@interface Item : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, strong) Link *link;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *commentsall;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, copy) NSString *online;

@property (nonatomic, copy) NSString *commentsUrl;

@property (nonatomic, copy) NSString *updateTime;

@property (strong, nonatomic) Sty *style;

@end

@interface Link : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *url;

@end

@interface Sty : NSObject

@property (strong, nonatomic) NSArray *images;
@property (strong, nonatomic) NSString *type;

@end

