//
//  HeaderDetailModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Meta,Body,Pre,Recommend,Slides;
@interface HeaderDetailModel : NSObject


@property (nonatomic, strong) Meta *meta;

@property (nonatomic, strong) Body *body;


@end
@interface Meta : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger o;

@property (nonatomic, copy) NSString *cla;

@end

@interface Body : NSObject

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, strong) NSArray<Recommend *> *recommend;

@property (nonatomic, copy) NSString *cate;

@property (nonatomic, strong) Pre *pre;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *wwwurl;

@property (nonatomic, copy) NSString *text;

@property (nonatomic, copy) NSString *shareurl;

@property (nonatomic, strong) NSArray<Slides *> *slides;

@property (nonatomic, copy) NSString *editTime;

@property (nonatomic, copy) NSString *commentsUrl;

@end

@interface Pre : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *type;

@end

@interface Recommend : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *links;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *thumbnail;

@end

@interface Slides : NSObject

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *desc;

@end

