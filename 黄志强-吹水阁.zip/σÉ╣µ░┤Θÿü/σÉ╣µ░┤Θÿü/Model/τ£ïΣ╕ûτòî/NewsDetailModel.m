//
//  NewsDetailModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/25.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsDetailModel.h"

@implementation NewsDetailModel

@end



@implementation NMeta

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id",@"cls":@"class"};
}

@end


@implementation NBody

+ (NSDictionary *)objectClassInArray{
    return @{@"img" : [Img class], @"videos" : [Videos class]};
}

@end


@implementation Img

@end


@implementation Videos

@end


@implementation Video

@end


@implementation Normal

@end


@implementation Hd

@end


@implementation Thumbnailsize

@end


