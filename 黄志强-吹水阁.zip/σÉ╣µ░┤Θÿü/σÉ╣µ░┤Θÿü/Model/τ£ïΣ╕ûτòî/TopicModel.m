//
//  TopicModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/26.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "TopicModel.h"

@implementation TopicModel

@end
@implementation TopicMetaModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}

@end


@implementation TopicBodyModel

+ (NSDictionary *)objectClassInArray{
    return @{@"subjects" : [BodySubjectsModel class]};
}

@end


@implementation BodyHeadModel

@end


@implementation SubContentModel

@end


@implementation BodySubjectsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"podItems" : [PodItemsModel class]};
}

@end


@implementation BodyContentModel

@end

@implementation PodItemsModel

+ (NSDictionary *)objectClassInArray{
    return @{@"links" : [PodItemsLinkModel class]};
}

@end

@implementation PodItemsLinkModel


@end


