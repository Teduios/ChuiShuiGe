//
//  HeaderDetailModel.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "HeaderDetailModel.h"

@implementation HeaderDetailModel

@end
@implementation Meta

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id",@"cla":@"class"};
}

@end


@implementation Body

+ (NSDictionary *)objectClassInArray{
    return @{@"recommend" : [Recommend class], @"slides" : [Slides class]};
}

@end


@implementation Pre

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}

@end


@implementation Recommend

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}

@end


@implementation Slides

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"desc":@"description"};
}

@end


