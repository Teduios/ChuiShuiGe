//
//  TopicModel.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/26.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TopicMetaModel,TopicBodyModel,BodyHeadModel,SubContentModel,BodySubjectsModel,BodyContentModel,PodItemsModel;
@interface TopicModel : NSObject


@property (nonatomic, strong) TopicMetaModel *meta;

@property (nonatomic, strong) TopicBodyModel *body;


@end
@interface TopicMetaModel : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger expireTime;

@end

@interface TopicBodyModel : NSObject

@property (nonatomic, strong) BodyHeadModel *head;

@property (nonatomic, strong) NSArray<BodySubjectsModel *> *subjects;

@property (nonatomic, strong) BodyContentModel *content;

@end

@interface BodyHeadModel : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *title;

@end

@interface BodyContentModel : NSObject

@property (nonatomic, copy) NSString *wwwUrl;

@property (nonatomic, copy) NSString *shareurl;

@property (nonatomic, copy) NSString *style;

@property (nonatomic, copy) NSString *color;

@property (nonatomic, copy) NSString *adurl;

@property (nonatomic, copy) NSString *nightColor;

@property (nonatomic, copy) NSString *slideAdId;

@property (nonatomic, copy) NSString *adpic;

@property (nonatomic, copy) NSString *createTime;

@end

@interface BodySubjectsModel : NSObject

@property (nonatomic, strong) SubContentModel *content;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *navTitle;
@property (nonatomic, strong) NSArray<PodItemsModel *> *podItems;

@property (nonatomic, copy) NSString *view;

@end

@interface SubContentModel : NSObject

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *bgImage;

@property (nonatomic, copy) NSString *altTitle;

@property (nonatomic, copy) NSString *customBanner;

@property (strong, nonatomic) NSString *intro;

@end


@interface PodItemsModel : NSObject

@property (nonatomic, strong) NSString *documentId;
@property (nonatomic, assign) double ago;
@property (nonatomic, strong) NSString *style;
@property (nonatomic, assign) BOOL hasSlide;
@property (nonatomic, strong) NSString *source;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *thumbnail;
@property (nonatomic, strong) NSString *commentUser;
@property (nonatomic, assign) double particpateCount;
@property (nonatomic, strong) NSString *updateTime;
@property (nonatomic, strong) NSString *intro;
@property (nonatomic, strong) NSString *shareUrl;
@property (nonatomic, strong) NSString *aid;
@property (nonatomic, strong) NSArray *links;
@property (nonatomic, assign) BOOL hasVideo;
@property (nonatomic, strong) NSString *commentOne;
@property (nonatomic, assign) double commentType;
@property (nonatomic, assign) double commentCount;
@property (nonatomic, strong) NSString *commentsUrl;
@property (nonatomic, strong) NSArray *thumbnails;

@end

@interface PodItemsLinkModel : NSObject

@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *url;

@end



