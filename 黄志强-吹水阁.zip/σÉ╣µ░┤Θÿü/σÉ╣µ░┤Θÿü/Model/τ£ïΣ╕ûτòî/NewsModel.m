//
//  NewsModel.m
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsModel.h"

@implementation NewsModel


+ (NSDictionary *)objectClassInArray{
    return @{@"esArray" : [Esarray class]};
}
@end
@implementation Esarray

+ (NSDictionary *)objectClassInArray{
    return @{@"item" : [Item class]};
}

@end


@implementation Item

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}

@end


@implementation Link

@end

@implementation Sty


@end

