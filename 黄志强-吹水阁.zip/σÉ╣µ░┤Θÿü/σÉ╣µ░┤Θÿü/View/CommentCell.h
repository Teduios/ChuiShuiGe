//
//  CommentCell.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/20.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentCell : UITableViewCell

/** 用户头像 */
@property (strong, nonatomic) CustomImageView *userIconView;

/** 用户名 */
@property (strong, nonatomic) UILabel *username;
/** 评论时间 */
@property (strong, nonatomic) UILabel *commentDate;

/** 评论信息 */
@property (strong, nonatomic) UILabel *comment;
@property (strong, nonatomic) UIButton *answerUser;
@property (strong, nonatomic) UILabel *answerLabel;

@end
