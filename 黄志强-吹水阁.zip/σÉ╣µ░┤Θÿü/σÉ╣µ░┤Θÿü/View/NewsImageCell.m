//
//  NewsImageCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsImageCell.h"

@implementation NewsImageCell

#pragma mark - 懒加载
- (UILabel *)titleLb {
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.textColor = kRGBColor(40, 40, 40);
    }
    return _titleLb;
}

- (CustomImageView *)image1 {
    if (_image1 == nil) {
        _image1 = [[CustomImageView alloc] init];
    }
    return _image1;
}

- (CustomImageView *)image2 {
    if (_image2 == nil) {
        _image2 = [[CustomImageView alloc] init];
    }
    return _image2;
}

- (CustomImageView *)image3 {
    if (_image3 == nil) {
        _image3 = [[CustomImageView alloc] init];
    }
    return _image3;
}

- (UILabel *)dateLb {
    if (_dateLb == nil) {
        _dateLb = [[UILabel alloc] init];
        _dateLb.font = [UIFont systemFontOfSize:12];
        _dateLb.textColor = [UIColor lightGrayColor];
    }
    return _dateLb;
}

- (UIButton *)comment {
    if (_comment == nil) {
        _comment = [[UIButton alloc] init];
        _comment.titleLabel.font = [UIFont systemFontOfSize:12];
        [_comment setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
    return _comment;
}



- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.image1];
        [self.contentView addSubview:self.image2];
        [self.contentView addSubview:self.image3];
        [self.contentView addSubview:self.dateLb];
        [self.contentView addSubview:self.comment];
        
        
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.height.mas_equalTo(25);
            make.right.mas_equalTo(-10);
        }];
        [_image1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_titleLb.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake((kWindowW-30)/3, (kWindowW-30)/3*0.65));
        }];
        [_image2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(_image1.mas_topMargin);
            make.left.mas_equalTo(_image1.mas_right).mas_equalTo(5);
            make.size.mas_equalTo(_image1);
        }];
        [_image3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(_image1.mas_topMargin);
            make.size.mas_equalTo(_image1);
            make.right.mas_equalTo(-10);
        }];
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_image1.mas_bottom).mas_equalTo(0);
            make.left.mas_equalTo(10);
            make.width.mas_equalTo(80);
            make.height.mas_equalTo(25);
        }];
        [_comment mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(120, 25));
            make.topMargin.mas_equalTo(_dateLb.mas_topMargin);
        }];
    }
    return self;
}








- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
