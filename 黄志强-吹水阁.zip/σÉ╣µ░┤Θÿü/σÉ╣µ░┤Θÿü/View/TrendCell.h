//
//  TrendCell.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/18.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrendCell : UITableViewCell

@property (strong, nonatomic) UILabel *trends;
@property (strong, nonatomic) UILabel *count;
@property (strong, nonatomic) UILabel *title;
@property (strong, nonatomic) UILabel *content;
@property (strong, nonatomic) UIImageView *imageV;

@end
