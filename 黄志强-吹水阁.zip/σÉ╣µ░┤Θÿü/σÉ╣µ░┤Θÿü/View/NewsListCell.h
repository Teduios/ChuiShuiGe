//
//  NewsListCell.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsListCell : UITableViewCell

/** 用来发图片 */
@property (strong, nonatomic) CustomImageView *iconView;
/** 标题 */
@property (strong, nonatomic) UILabel *titleLb;
/** 时间 */
@property (strong, nonatomic) UILabel *dateLb;
/** 评论 */
@property (strong, nonatomic) UIButton *comment;

@end
