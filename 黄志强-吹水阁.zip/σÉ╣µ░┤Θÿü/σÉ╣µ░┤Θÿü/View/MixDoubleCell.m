//
//  MixDoubleCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "MixDoubleCell.h"

@implementation MixDoubleCell
#pragma mark - 懒加载
- (UIView *)mixView {
    if (_mixView == nil) {
        _mixView = [[UIView alloc] init];
        _mixView.backgroundColor = [UIColor whiteColor];
        NSString *gifPath = [[NSBundle mainBundle] pathForResource:@"mix_lufei" ofType:@"gif"];
        NSString *html = [NSString stringWithFormat:@"<body leftmargin=\"0px\" topmargin=\"0px\"></body><img src=\"file:///%@\" width=\"%f\" height=\"250\"/>",gifPath,kWindowW];
        UIWebView *webView = [[UIWebView alloc] init];
        webView.userInteractionEnabled = NO;//用户不可交互
        [webView loadHTMLString:html baseURL:nil];
        [_mixView addSubview:webView];
        [webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
    }
    return _mixView;
}

- (UIButton *)goBtn {
    if (_goBtn == nil) {
        _goBtn = [[UIButton alloc] init];
//        [_goBtn setTitle:@"进入男女大乱斗吧~~" forState:UIControlStateNormal];
//        _goBtn.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    }
    return _goBtn;
}





- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.mixView];
        UILabel *mixLb = [[UILabel alloc] init];
        mixLb.text = @"进入男女大乱斗吧~";
        mixLb.textColor = [UIColor whiteColor];
        mixLb.textAlignment = NSTextAlignmentCenter;
        mixLb.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        mixLb.font = kTitleFont;
        [self.mixView addSubview:mixLb];
        
        [self.mixView addSubview:self.goBtn];
        [_mixView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.right.left.bottom.mas_equalTo(0);
            make.height.mas_equalTo(250);
        }];
        [_goBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.right.left.bottom.mas_equalTo(0);
            make.height.mas_equalTo(250);
        }];
        
        [mixLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(40);
        }];
        
    }
    return self;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    
}

@end
