//
//  SeparateCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "SeparateCell.h"

@implementation SeparateCell

#pragma mark - 懒加载
- (UIView *)manView {
    if (_manView == nil) {
        _manView = [[UIView alloc] init];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"man_cat" ofType:@"gif"];
        UIWebView *webView = [[UIWebView alloc] init];
        webView.userInteractionEnabled = NO;//用户不可交互
        NSString *html = [NSString stringWithFormat:@"<body leftmargin=\"0px\" topmargin=\"0px\"></body><img src=\"file:///%@\" width=\"%f\" height=\"250\"/>",path,kWindowW/2];
        [webView loadHTMLString:html baseURL:nil];
        [_manView addSubview:webView];
        [webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _manView;
}

- (UIButton *)goManBtn {
    if (_goManBtn == nil) {
        _goManBtn = [[UIButton alloc] init];
    }
    return _goManBtn;
}


- (UIView *)womenView {
    if (_womenView == nil) {
        _womenView = [[UIView alloc] init];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"girl" ofType:@"gif"];
        NSString *html = [NSString stringWithFormat:@"<body leftmargin=\"0px\" topmargin=\"0px\"></body><img src=\"file:///%@\" width=\"%f\" height=\"250\"/>",path,kWindowW/2-5];
        UIWebView *webView = [[UIWebView alloc] init];
        webView.userInteractionEnabled = NO;//用户不可交互
        [webView loadHTMLString:html baseURL:nil];
        [_womenView addSubview:webView];
        [webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _womenView;
}

- (UIButton *)goWomenBtn {
    if (_goWomenBtn == nil) {
        _goWomenBtn = [[UIButton alloc] init];
    }
    return _goWomenBtn;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.manView];
        [self.contentView addSubview:self.womenView];
        [self.manView addSubview:self.goManBtn];
        [self.womenView addSubview:self.goWomenBtn];
        
        UILabel *manLb = [[UILabel alloc] init];
        manLb.text = @"男生地盘";
        manLb.textColor = [UIColor whiteColor];
        manLb.textAlignment = NSTextAlignmentCenter;
        manLb.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        manLb.font = kTitleFont;
        [self.manView addSubview:manLb];
        
        UILabel *womenLb = [[UILabel alloc] init];
        womenLb.text = @"后宫三千";
        womenLb.textColor = [UIColor whiteColor];
        womenLb.textAlignment = NSTextAlignmentCenter;
        womenLb.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        womenLb.font = kTitleFont;
        [self.womenView addSubview:womenLb];
        
        [_manView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(0);
            make.right.mas_equalTo(_womenView.mas_left).mas_equalTo(-10);
            make.height.mas_equalTo(250);
            make.bottom.mas_equalTo(0);
        }];
        
        [_goManBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(0);
            make.right.mas_equalTo(_womenView.mas_left).mas_equalTo(-10);
            make.height.mas_equalTo(250);
            make.bottom.mas_equalTo(0);
        }];
        
        [manLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(40);
        }];
        
        [_womenView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_manView);
            make.right.top.mas_equalTo(0);
        }];
        
        [_goWomenBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_manView);
            make.right.top.mas_equalTo(0);
        }];
        
        [womenLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(40);
        }];
        
        
        
    }
    return self;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
