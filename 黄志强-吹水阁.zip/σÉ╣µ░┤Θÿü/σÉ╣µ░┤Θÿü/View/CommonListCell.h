//
//  CommonListCell.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommonListCell : UITableViewCell

/** 用户头像 */
@property (strong, nonatomic) CustomImageView *userIcon;
/** 用户名 */
@property (strong, nonatomic) UILabel *nikeName;
/** 创建时间 */
@property (strong, nonatomic) UILabel *createDate;
/** 点赞数 */
@property (strong, nonatomic) UIButton *likeBtn;
/** 评论数 */
@property (strong, nonatomic) UIButton *commentBtn;
/** 标题 */
@property (strong, nonatomic) UILabel *titleLb;
/** 内容简述 */
@property (strong, nonatomic) UILabel *contentLb;
/** 照片 */
@property (strong, nonatomic) UIView *allImagesView;

@end
