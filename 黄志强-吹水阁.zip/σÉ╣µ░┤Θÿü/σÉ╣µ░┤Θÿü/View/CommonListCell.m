//
//  CommonListCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommonListCell.h"

@implementation CommonListCell
#pragma mark - 懒加载
- (CustomImageView *)userIcon {
    if (_userIcon == nil) {
        _userIcon = [[CustomImageView alloc] init];
        _userIcon.layer.cornerRadius = 20;
        _userIcon.layer.masksToBounds = YES;
    }
    return _userIcon;
}


- (UILabel *)nikeName {
    if (_nikeName == nil) {
        _nikeName = [[UILabel alloc] init];
        _nikeName.font = [UIFont systemFontOfSize:16];
    }
    return _nikeName;
}

- (UILabel *)createDate {
    if (_createDate == nil) {
        _createDate = [[UILabel alloc] init];
        _createDate.font = kCommentFont;
        _createDate.textColor = kRGBColor(100, 100, 100);
    }
    return _createDate;
}

- (UIButton *)likeBtn {
    if (_likeBtn == nil) {
        _likeBtn = [[UIButton alloc] init];
        _likeBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [_likeBtn setImage:[UIImage imageNamed:@"qbf_like"] forState:UIControlStateNormal];
        [_likeBtn setTitleColor:kRGBColor(100, 100, 100) forState:UIControlStateNormal];
        _likeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        _likeBtn.hidden = YES;
    }
    return _likeBtn;
}

- (UIButton *)commentBtn {
    if (_commentBtn == nil) {
        _commentBtn = [[UIButton alloc] init];
        _commentBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [_commentBtn setImage:[UIImage imageNamed:@"qbf_chat"] forState:UIControlStateNormal];
        [_commentBtn setTitleColor:kRGBColor(100, 100, 100) forState:UIControlStateNormal];
        _commentBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        _commentBtn.hidden = YES;
    }
    return _commentBtn;
}

- (UILabel *)titleLb {
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = kTitleFont;
        _titleLb.numberOfLines = 2;
    }
    return _titleLb;
}

- (UILabel *)contentLb {
    if (_contentLb == nil) {
        _contentLb = [[UILabel alloc] init];
        _contentLb.font = kContentFont;
        _contentLb.textColor = kRGBColor(90, 90, 90);
        _contentLb.numberOfLines = 0;
    }
    return _contentLb;
}

- (UIView *)allImagesView {
    if (_allImagesView == nil) {
        _allImagesView = [[UIView alloc] init];
    }
    return _allImagesView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self.contentView addSubview:self.userIcon];
        [self.contentView addSubview:self.nikeName];
        [self.contentView addSubview:self.createDate];
        [self.contentView addSubview:self.likeBtn];
        [self.contentView addSubview:self.commentBtn];
        
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.contentLb];
        [self.contentView addSubview:self.allImagesView];

        [_userIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        [_nikeName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_userIcon.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(_likeBtn.mas_left).mas_equalTo(0);
            make.top.mas_equalTo(10);
            make.bottom.mas_equalTo(_createDate.mas_top);
        }];
        [_createDate mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(_nikeName.mas_leftMargin);
            make.width.mas_equalTo(150);
            make.bottomMargin.mas_equalTo(_userIcon.mas_bottomMargin);
        }];
        [_likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 30));
            make.topMargin.mas_equalTo(_userIcon.mas_topMargin);
            make.right.mas_equalTo(_commentBtn.mas_left).mas_equalTo(0);
        }];
        [_commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_likeBtn);
            make.right.mas_equalTo(10);
            make.topMargin.mas_equalTo(_userIcon.mas_topMargin);
        }];
        
        
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_userIcon.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        [_contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_titleLb.mas_bottom).mas_equalTo(5);
            make.height.mas_lessThanOrEqualTo(40);
            make.right.mas_equalTo(-10);
        }];
        [_allImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_contentLb.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(0);
            make.bottom.mas_equalTo(-4);
        }];
        
        
    }
    return self;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
