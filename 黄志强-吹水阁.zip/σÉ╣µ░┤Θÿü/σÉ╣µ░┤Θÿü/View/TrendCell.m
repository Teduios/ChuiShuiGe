//
//  TrendCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/18.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "TrendCell.h"

@implementation TrendCell
#pragma mark - 懒加载
- (UILabel *)trends {
    if (_trends == nil) {
        _trends = [[UILabel alloc] init];
        _trends.font = [UIFont boldSystemFontOfSize:16];
        _trends.textAlignment = NSTextAlignmentCenter;
        _trends.text = @"动态";
    }
    return _trends;
}

- (UILabel *)count {
    if (_count == nil) {
        _count = [[UILabel alloc] init];
        _count.font = [UIFont boldSystemFontOfSize:24];
        _count.textColor = [UIColor brownColor];
        _count.textAlignment = NSTextAlignmentCenter;
    }
    return _count;
}

- (UIImageView *)imageV {
    if (_imageV == nil) {
        _imageV = [[UIImageView alloc] init];
    }
    return _imageV;
}

- (UILabel *)title {
    if (_title == nil) {
        _title = [[UILabel alloc] init];
        _title.numberOfLines = 2;
    }
    return _title;
}

- (UILabel *)content {
    if (_content == nil) {
        _content = [[UILabel alloc] init];
        _content.textColor = [UIColor grayColor];
        _content.font = [UIFont systemFontOfSize:14];
        _content.textAlignment = NSTextAlignmentNatural;
        _content.numberOfLines = 2;
    }
    return _content;
}



- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self.contentView addSubview:self.trends];
        [self.contentView addSubview:self.count];
        [self.contentView addSubview:self.title];
        [self.contentView addSubview:self.content];
        [self.contentView addSubview:self.imageV];
        
        [_trends mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(80, 20));
        }];
        [_count mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_trends.mas_bottom).mas_equalTo(0);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(80, 40));
        }];
        [_imageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(60, 60));
            make.left.mas_equalTo(_trends.mas_right).mas_equalTo(0);
        }];
        
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(_imageV.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(30);
        }];
        [_content mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_title.mas_bottom).mas_equalTo(4);
            make.leftMargin.mas_equalTo(_title.mas_leftMargin);
            make.rightMargin.mas_equalTo(_title.mas_rightMargin);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
