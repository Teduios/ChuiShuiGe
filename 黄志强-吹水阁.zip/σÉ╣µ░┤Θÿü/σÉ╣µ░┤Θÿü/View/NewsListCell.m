//
//  NewsListCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsListCell.h"

@implementation NewsListCell
#pragma mark - 懒加载
- (CustomImageView *)iconView {
    if (_iconView == nil) {
        _iconView = [[CustomImageView alloc] init];
    }
    return _iconView;
}

- (UILabel *)titleLb {
    if (_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.textColor = kRGBColor(40, 40, 40);
        _titleLb.numberOfLines = 2;
    }
    return _titleLb;
}

- (UILabel *)dateLb {
    if (_dateLb == nil) {
        _dateLb = [[UILabel alloc] init];
        _dateLb.text = @"专题";
        _dateLb.backgroundColor = kColor;
        _dateLb.textColor = [UIColor whiteColor];
        _dateLb.font = [UIFont systemFontOfSize:13];
    }
    return _dateLb;
}

- (UIButton *)comment {
    if (_comment == nil) {
        _comment = [[UIButton alloc] init];
        _comment.titleLabel.font = [UIFont systemFontOfSize:13];
        [_comment setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
    return _comment;
}



- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconView];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.dateLb];
        [self.contentView addSubview:self.comment];
        
        [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(91, 66));
        }];
        
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconView.mas_right).mas_equalTo(10);
            make.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(45);
        }];
        
        [_dateLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(_titleLb.mas_leftMargin);
            make.width.mas_lessThanOrEqualTo(80);
            make.height.mas_equalTo(12);
            make.bottomMargin.mas_equalTo(_iconView.mas_bottomMargin);
        }];
        
        [_comment mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.bottomMargin.mas_equalTo(_iconView.mas_bottom);
            make.size.mas_equalTo(CGSizeMake(100, 24));
        }];
        
    }
    return self;
}






- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
