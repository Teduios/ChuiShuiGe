//
//  CommentCell.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/20.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommentCell.h"


@implementation CommentCell
#pragma mark - 懒加载
- (CustomImageView *)userIconView {
    if (_userIconView == nil) {
        _userIconView = [[CustomImageView alloc] init];
        _userIconView.layer.cornerRadius = 20;
        _userIconView.layer.masksToBounds = YES;
    }
    return _userIconView;
}

- (UILabel *)username {
    if (_username == nil) {
        _username = [[UILabel alloc] init];
    }
    return _username;
}

- (UILabel *)commentDate {
    if (_commentDate == nil) {
        _commentDate = [[UILabel alloc] init];
        _commentDate.font = kCommentFont;
        _commentDate.textColor = [UIColor grayColor];
        _commentDate.textAlignment = NSTextAlignmentRight;
    }
    return _commentDate;
}

- (UILabel *)comment {
    if (_comment == nil) {
        _comment = [[UILabel alloc] init];
        _comment.font = kCommentFont;
        _comment.numberOfLines = 0;
    }
    return _comment;
}

- (UIButton *)answerUser {
    if (_answerUser == nil) {
        _answerUser = [[UIButton alloc] init];
        _answerUser.titleLabel.font = kCommentFont;
        _answerUser.hidden = YES;
    }
    return _answerUser;
}

- (UILabel *)answerLabel {
    if (_answerLabel == nil) {
        _answerLabel = [[UILabel alloc] init];
        _answerLabel.font = kCommentFont;
        _answerLabel.text = @"回复";
        _answerLabel.hidden = YES;
    }
    return _answerLabel;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.userIconView];
        [self.contentView addSubview:self.commentDate];
        [self.contentView addSubview:self.username];
        
        [self.contentView addSubview:self.answerLabel];
        [self.contentView addSubview:self.answerUser];
        [self.contentView addSubview:self.comment];
        
        [_userIconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(15);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        
        [_username mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_userIconView.mas_right).mas_equalTo(10);
            make.top.mas_equalTo(15);
            make.right.mas_equalTo(-120);
            make.height.mas_equalTo(20);
        }];
        
        [_commentDate mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(15);
            make.width.mas_equalTo(100);
        }];
        
        [_answerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_username.mas_bottom).mas_equalTo(0);
            make.leftMargin.mas_equalTo(_username.mas_leftMargin);
            make.width.mas_equalTo(50);
        }];
        
        [_answerUser mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_answerLabel.mas_right).mas_equalTo(0);
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(_answerLabel.mas_topMargin);
        }];
        
        [_comment mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_username.mas_bottom).mas_equalTo(2);
            make.leftMargin.mas_equalTo(_username.mas_leftMargin);
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(-15);
        }];
        
    }
    return self;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
