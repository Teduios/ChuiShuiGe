//
//  NSString+Extension.h
//  weibo
//
//  Created by apple-jd37 on 15/11/13.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)

- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW;

- (CGSize)sizeWithFont:(UIFont *)font;

@end
