//
//  CustomImageView.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/11.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomImageView : UIView

@property (strong, nonatomic) UIImageView *imageView;
@property (strong, nonatomic) UIButton *imageButton;


@end
