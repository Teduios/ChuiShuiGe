//
//  CustomImageView.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/11.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CustomImageView.h"

@interface CustomImageView ()<UIGestureRecognizerDelegate>

@property (strong, nonatomic) UIImageView *photoView;

@end
@implementation CustomImageView

-(id)init
{
    if (self = [super init]) {
        _imageView = [UIImageView new];
        _imageButton = [UIButton new];
        [self addSubview:_imageView];
        [self addSubview:_imageButton];
        
        //按比例放大,充满
        _imageView.contentMode = UIViewContentModeScaleAspectFill;
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_imageButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        //当前视图容易减掉超出自身区域的视图
        self.clipsToBounds = YES;
    }
    return self;
}

- (UIImageView *)photoView {
    if (_photoView == nil) {
        _photoView = [[UIImageView alloc] init];
    }
    return _photoView;
}

// 图片浏览
- (void)showPhoto {
    UIWindow *win = [[UIApplication sharedApplication].windows lastObject];
    self.photoView =self.imageView;
    //开启图片的用户交互功能
    _imageView.userInteractionEnabled = YES;
    [win addSubview:_imageView];
    
    //设置初始状态
    [self loadImageView];
    
    // 添加pan手势
    UIPanGestureRecognizer *panGR = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    [_imageView addGestureRecognizer:panGR];
    // 添加缩放
    UIPinchGestureRecognizer *pinchGR = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinch:)];
    pinchGR.delegate = self;
    [_imageView addGestureRecognizer:pinchGR];
    // 添加旋转
    UIRotationGestureRecognizer *rotationGR = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotation:)];
    rotationGR.delegate = self;
    [_imageView addGestureRecognizer:rotationGR];
    
    // 添加tap手势
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tapGR.numberOfTapsRequired = 2;
    [_imageView addGestureRecognizer:tapGR];
}


-(void)pan:(UIPanGestureRecognizer *)gr
{
    // 读取self.view下的偏移量，搭配修改center属性，因为center是参考self.view坐标系
    //    CGPoint translate = [gr translationInView:self.view];
    //    CGPoint center = self.imageView.center;
    //    center.x+=translate.x;
    //    center.y +=translate.y;
    //    self.imageView.center= center;
    //    [gr setTranslation:CGPointZero inView:self.view]
    // 读取imageView下的偏移量，搭配修改transform属性中的translate，因为translate是参考self.imageView坐标系
    CGPoint translate = [gr translationInView:self.photoView];
    self.photoView.transform = CGAffineTransformTranslate(self.photoView.transform, translate.x, translate.y);
    [gr setTranslation:CGPointZero inView:self.photoView];
}

-(void)pinch:(UIPinchGestureRecognizer *)gr{
    self.photoView.transform = CGAffineTransformScale(self.photoView.transform, gr.scale, gr.scale);
    gr.scale = 1;
}

-(void)rotation:(UIRotationGestureRecognizer *)gr
{
    self.photoView.transform = CGAffineTransformRotate(self.photoView.transform, gr.rotation);
    gr.rotation = 0;
}

-(void)tap:(UITapGestureRecognizer *)gr
{
    [self loadImageView];
}

-(void)loadImageView
{
    // 显示到中间
    self.photoView.center = [[UIApplication sharedApplication].windows lastObject].center;
    
    // 缩放，看到全部
    CGFloat scaleX = [[UIApplication sharedApplication].windows lastObject].bounds.size.width/self.photoView.bounds.size.width;
    CGFloat scaleY = [[UIApplication sharedApplication].windows lastObject].bounds.size.height/self.photoView.bounds.size.height;
    CGFloat scale = MIN(scaleX, scaleY);
    self.photoView.transform = CGAffineTransformMakeScale(scale, scale);
    
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}




@end
