//
//  NewsNetworkManager.h
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "BaseNetworkManager.h"
#import "NewsModel.h"
#import "NewsNetworkHeader.h"
#import "HeaderDetailModel.h"
#import "NewsDetailModel.h"
#import "TopicModel.h"


typedef NS_ENUM(NSUInteger, NewsType) {
    NewsTypeTouTiao,     // 头条
    NewsTypeYuLe,        // 娱乐
    NewsTypeShiZheng,    // 时政
    NewsTypeKeJi,        // 科技
    NewsTypeJunShi       // 军事
};
@interface NewsNetworkManager : BaseNetworkManager

/**
 *  根据不同的新闻类型获得对应的新闻
 *
 *  @param type             新闻类型
 *  @param completionHandle 新闻
 */
+ (void)getNewWithType:(NewsType)type andPage:(NSInteger)page completionHandle:(void(^)(NewsModel *model,NSError *error))completionHandle;

/**
 *  通过地址获取头部图片的详情页面数据
 *
 *  @param path             地址
 *  @param completionHandle 头部图片详情内容
 */
+ (void)getHeaderDetailForPath:(NSString *)path completionHandle:(void(^)(HeaderDetailModel *model, NSError *error))completionHandle;

/**
 *  获取新闻详情页内容
 *
 *  @param path             地址
 *  @param completionHandle 内容
 */
+ (void)getNewsDetailForPath:(NSString *)path completionHandle:(void(^)(NewsDetailModel *model, NSError *error))completionHandle;

/**
 *  获取新闻专题内容
 *
 *  @param path             地址
 *  @param completionHandle 内容
 */
+ (void)getNewsTopicForPath:(NSString *)path completionHandle:(void(^)(TopicModel *model, NSError *error))completionHandle;

@end
