//
//  NewsNetworkHeader.h
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#ifndef NewsNetworkHeader_h
#define NewsNetworkHeader_h

/**
 *  存放接口的地址
 */

/** 新闻地址 */
#define kNewsPath @"http://api.iclient.ifeng.com/ClientNews?"
/**  */


#endif /* NewsNetworkHeader_h */
