//
//  NewsNetworkManager.m
//  吹水阁
//
//  Created by Hanten on 15/11/16.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsNetworkManager.h"

#define kGv @"4.6.5"
#define kAv @"0"
#define kVt @"5"
#define kProid @"ifengnews"
#define kOs [NSString stringWithFormat:@"ios_%f",[UIDevice currentDevice].systemVersion.floatValue]
#define kScreen [NSString stringWithFormat:@"%.fx%.f",kWindowW,kWindowH]
#define kPublishid @"4002"
#define kUid @"9a82f1b45f724f594eea2ae6e873cdc7a402b7d7"

@implementation NewsNetworkManager

+ (void)getNewWithType:(NewsType)type andPage:(NSInteger)page completionHandle:(void (^)(NewsModel *, NSError *))completionHandle {
    NSString *path = kNewsPath;
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:kGv,@"gv",kAv,@"av",kVt,@"vt",kProid,@"proid",kOs,@"os",kScreen,@"screen",kPublishid,@"publishid",kUid,@"uid", nil];
    
    
    
    switch (type) {
        case NewsTypeKeJi:
            [params setValue:@"KJ123,FOCUSKJ123" forKey:@"id"];
            break;
        case NewsTypeYuLe:
            [params setValue:@"YL53,FOCUSYL53" forKey:@"id"];
            break;
        case NewsTypeJunShi:
            [params setValue:@"JS83,FOCUSJS83" forKey:@"id"];
            break;
        case NewsTypeTouTiao:
            [params setValue:@"SYLB10,SYDT10,SYRECOMMEND" forKey:@"id"];
            break;
        case NewsTypeShiZheng:
            [params setValue:@"SZPD,FOCUSSZPD" forKey:@"id"];
            break;
            
        default:
            break;
    }
    [params setValue:@(page) forKey:@"page"];
    
    [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        
        NSArray *arr = responseObj;
        NSMutableArray *msArr = [NSMutableArray array];
        NSDictionary *dic = arr[0];
        Esarray *sa = [Esarray mj_objectWithKeyValues:dic];
        [msArr addObject:sa];
        if (arr.count > 1) {
            NSDictionary *dic1 = arr[1];
            Esarray *sa1 = [Esarray mj_objectWithKeyValues:dic1];
            [msArr addObject:sa1];
        }
        
        NewsModel *m = [[NewsModel alloc] init];
        m.esArray = [msArr copy];
        
        completionHandle(m,error);
    }];
    
    
}


+ (void)getHeaderDetailForPath:(NSString *)path completionHandle:(void(^)(HeaderDetailModel *model, NSError *error))completionHandle {
    [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HeaderDetailModel mj_objectWithKeyValues:responseObj],error);
    }];
}


+ (void)getNewsDetailForPath:(NSString *)path completionHandle:(void(^)(NewsDetailModel *model, NSError *error))completionHandle {
    [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([NewsDetailModel mj_objectWithKeyValues:responseObj],error);
    }];
}

+ (void)getNewsTopicForPath:(NSString *)path completionHandle:(void(^)(TopicModel *model, NSError *error))completionHandle {
    [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TopicModel mj_objectWithKeyValues:responseObj],error);
    }];
}

@end
