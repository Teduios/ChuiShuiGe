//
//  PhotoBrowserViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/23.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "PhotoBrowserViewController.h"
#import "HeaderDetailViewModel.h"
#define kWinW [UIScreen mainScreen].bounds.size.width
#define kWinH [UIScreen mainScreen].bounds.size.height

@interface PhotoBrowserViewController ()<UIScrollViewDelegate,UIGestureRecognizerDelegate>

@property (strong, nonatomic) UIScrollView *imageSV;           // 存放图片视图
@property (strong, nonatomic) UIView *textView;                // 存放文字视图
@property (strong, nonatomic) UIView *backView;                // 返回等视图
@property (strong, nonatomic) UILabel *pageCount;              // 显示当前的页数
@property (strong, nonatomic) UILabel *textLb;                 // 文字内容
@property (strong, nonatomic) UILabel *pageCount2;             // 未隐藏前的页数
@property (strong, nonatomic) UIImageView *currentView;        // 用来记录当前图片
@property (strong, nonatomic) HeaderDetailViewModel *headerVM;

@end

@implementation PhotoBrowserViewController

- (instancetype)initWithPhoto {
    if (self = [super init]) {
        self.textView.hidden = YES;
        self.backView.hidden = YES;
    }
    return self;
}

- (instancetype)initWithPhotoAndText {
    if ((self = [super init])) {
    }
    return self;
}


#pragma mark - 懒加载
- (UIScrollView *)imageSV {
    if (_imageSV == nil) {
        _imageSV = [[UIScrollView alloc] init];
        _imageSV.frame = CGRectMake(0, 0, kWinW, kWinH);
        _imageSV.contentSize = CGSizeMake(kWinW * self.allImagesArr.count, 0);
        _imageSV.pagingEnabled = YES;
        _imageSV.delegate = self;
        _imageSV.bounces = NO;
        _imageSV.showsHorizontalScrollIndicator = NO;
    }
    return _imageSV;
}

- (UIView *)textView {
    if (_textView == nil) {
        _textView = [[UIView alloc] init];
        _textView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        _textView.frame = CGRectMake(0, kWinH - kWinW * 0.4, kWinW, kWinH);
        
    }
    return _textView;
}

- (UILabel *)textLb {
    if (_textLb == nil) {
        _textLb = [[UILabel alloc] init];
        [self.textView addSubview:_textLb];
        [_textLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-75);
            make.top.mas_equalTo(10);
        }];
        _textLb.numberOfLines = 0;
        _textLb.font = kCommentFont;
        _textLb.textColor = [UIColor whiteColor];
        [_textLb alignTop];
    }
    return _textLb;
}

- (UILabel *)pageCount2 {
    if (_pageCount2 == nil) {
        _pageCount2 = [[UILabel alloc] init];
        [self.textView addSubview:_pageCount2];
        _pageCount2.textAlignment = NSTextAlignmentRight;
        _pageCount2.frame = CGRectMake(kWinW - 72, 0, 70, 30);
        _pageCount2.textColor = [UIColor whiteColor];
        _pageCount2.font = [UIFont boldSystemFontOfSize:20];
    }
    return _pageCount2;
}

- (UIView *)backView {
    if (_backView == nil) {
        _backView = [[UIView alloc] init];
        _backView.backgroundColor = [UIColor blackColor];
        _backView.frame = CGRectMake(0, kWinH - 60, kWinW, 60);
        UIButton *backBtn = [[UIButton alloc] init];
        [_backView addSubview:backBtn];
        backBtn.frame = CGRectMake(0, 0, 60, 60);
        [backBtn setTitle:@"返回" forState:UIControlStateNormal];
        backBtn.titleLabel.font = [UIFont systemFontOfSize:18];
        [backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [backBtn addTarget:self action:@selector(backToBefore) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backView;
}

- (UILabel *)pageCount {
    if (_pageCount == nil) {
        _pageCount = [[UILabel alloc] init];
        _pageCount.frame = CGRectMake((kWinW - 50)/2, kWinH - 40, 80, 30);
        _pageCount.hidden = YES;
        _pageCount.textColor = [UIColor whiteColor];
        _pageCount.font = [UIFont boldSystemFontOfSize:20];
    }
    return _pageCount;
}

- (UIImageView *)currentView {
    if (_currentView == nil) {
        _currentView = [[UIImageView alloc] init];
    }
    return _currentView;
}


- (HeaderDetailViewModel *)headerVM {
    if (_headerVM == nil) {
        _headerVM = [[HeaderDetailViewModel alloc] init];
    }
    return _headerVM;
}



- (void)backToBefore {
    [self.navigationController popViewControllerAnimated:YES];
}




- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.headerVM.path = self.path;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    __weak typeof(self) headerVC = self;
    [self.headerVM getDataCompletionHandle:^(NSError *error) {
        hud.hidden = YES;
        headerVC.allImagesArr = [headerVC.headerVM allImagesArr];
        headerVC.allTextsArr = [headerVC.headerVM allTextsArr];
        [headerVC addImage];
        
    }];
  

}

- (void)addImage {
    
    // 添加图片和文字
    NSInteger count = self.allImagesArr.count;
    [self.view addSubview:self.imageSV];
    [self.view addSubview:self.textView];
    [self.view addSubview:self.backView];
    [self.view addSubview:self.pageCount];
    for (int i = 0; i < count; i++) {
        UIImageView *imageV = [[UIImageView alloc] init];
        imageV.contentMode = UIViewContentModeScaleAspectFit;
        imageV.tag = 100 + i;
        UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinch:)];
        pinch.delegate = self;
        [imageV addGestureRecognizer:pinch];
        imageV.userInteractionEnabled = YES;
        imageV.frame = CGRectMake(kWinW * i, 0, kWinW, self.imageSV.height);
        [imageV sd_setImageWithURL:self.allImagesArr[i] placeholderImage:[UIImage imageNamed:@"ghostbb_unhappy_270_330"]];
        [self.imageSV addSubview:imageV];
    }
    self.textLb.text = self.allTextsArr[0];
    self.pageCount.text = [NSString stringWithFormat:@"1/%ld",self.allImagesArr.count];
    self.pageCount2.text = [NSString stringWithFormat:@"1/%ld",self.allImagesArr.count];
    // 添加手势让下部文字视图和返回视图隐藏
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideView)];
    [self.imageSV addGestureRecognizer:tap];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panView:)];
    [self.textView addGestureRecognizer:pan];
    
}

// 图片缩放
- (void)pinch:(UIPinchGestureRecognizer *)pinch {
    self.currentView.transform = CGAffineTransformScale(self.currentView.transform, pinch.scale, pinch.scale);
    pinch.scale = 1;
}
// 移动显示文字
- (void)panView:(UIPanGestureRecognizer *)pan {
    // location:绝对位置,所有点都相对于self.view的左顶点的距离
    // translation：位移(位置的偏移量，所有点都相对于动作起点的距离)
    //CGPoint location = [gr locationInView:self.view];
    CGPoint translation = [pan translationInView:self.view];
    CGPoint leftTop = self.textView.origin;
    if (translation.y > 0) {
        [UIView animateWithDuration:1 animations:^{
           self.textView.y = kWinH - kWinW * 0.4;
        }];
        return;
    }
    leftTop.y += translation.y;
    if (leftTop.y <= 20) {
        leftTop.y = 20;
    }else if (leftTop.y >= kWinH - kWinW * 0.4) {
        leftTop.y = kWinH - kWinW * 0.4;
    }
    self.textView.origin = leftTop;
    
    //将本次移动的距离归零
    //每次用完translation后归零
    //意味着下一次的偏移量就是相对于这一次的偏移量了
    //不再是相对于起点了
    [pan setTranslation:CGPointZero inView:self.view];
}


// 隐藏视图
- (void)hideView {
    self.textView.hidden = !self.textView.hidden;
    self.backView.hidden = !self.backView.hidden;
    self.pageCount.hidden = !self.pageCount.hidden;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGPoint offSet = scrollView.contentOffset;
    NSInteger currentPage = offSet.x/kWinW + 0.5;
    self.currentView = [self.imageSV viewWithTag:(100 + currentPage)];
    self.textLb.text = self.allTextsArr[currentPage];
    if (self.allImagesArr.count > 1) {
        self.currentView.transform = CGAffineTransformMakeScale(1, 1);
        self.pageCount.text = [NSString stringWithFormat:@"%ld/%ld",currentPage+1,self.allImagesArr.count];
        self.pageCount2.text = [NSString stringWithFormat:@"%ld/%ld",currentPage+1,self.allImagesArr.count];
    }
}



@end
