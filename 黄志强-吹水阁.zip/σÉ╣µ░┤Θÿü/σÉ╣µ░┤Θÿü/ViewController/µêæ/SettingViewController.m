//
//  UserDescViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/14.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "SettingViewController.h"
#import "AboutViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (instancetype)initWithStyle:(UITableViewStyle)style {
    if (self = [super initWithStyle:UITableViewStyleGrouped]) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"设置";
    self.view.backgroundColor = kRGBColor(247, 247, 247);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 2;
            
        default:
            return 1;
    }
}

kRemoveCellSeparator

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"Cell"];
    switch (indexPath.section) {
        case 0:
            if (indexPath.row == 0) {
                cell.textLabel.text = @"关于吹水阁";
            }else {
                cell.textLabel.text = @"版本信息";
                cell.detailTextLabel.text = @"1.0";
                cell.userInteractionEnabled = NO;
                
            }
            break;
        case 1:{
            UILabel *loginOut = [[UILabel alloc] init];
            loginOut.text = @"退出登录";
            loginOut.textColor = [UIColor redColor];
            loginOut.textAlignment = NSTextAlignmentCenter;
            [cell.contentView addSubview:loginOut];
            [loginOut mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(cell.contentView);
            }];
        }
            break;
        default:
            break;
    }
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            AboutViewController *vc = [[AboutViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
    if (indexPath.section == 1) {
        [BmobUser logout];
        [self backToNotLogin];
    }
    
}


- (void)backToNotLogin {
        // 获取系统提供的通知中心对象
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        // 向通知中心发通知
        // name:通知名称 object：发送方对象是谁（通知是谁发的） userInfo：通知中携带的具体的信息
        [center postNotificationName:@"LoginOut" object:nil];
        [self.navigationController popViewControllerAnimated:YES];
}

@end
