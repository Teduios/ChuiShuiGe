//
//  LoginViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/14.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"

@interface LoginViewController ()

/** 用户名 */
@property (strong, nonatomic) UITextField *userName;
/** 用户密码 */
@property (strong, nonatomic) UITextField *password;
/** 登录按钮 */
@property (strong, nonatomic) UIButton *loginButton;
/** 跳转注册 */
@property (strong, nonatomic) UIButton *registerButton;

@property (strong, nonatomic) UIImageView *imageView;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"登录界面";
    self.view.backgroundColor = kRGBColor(247, 247, 247);
    self.userName.placeholder = @"请输入账号";
    self.password.placeholder = @"输入你的密码";
    self.loginButton.hidden = NO;
    self.registerButton.hidden = NO;
    self.imageView.hidden = NO;
    
    UIButton *back = [[UIButton alloc] init];
    [back setBackgroundImage:[UIImage imageNamed:@"navigationbar_back_highlighted"] forState:UIControlStateNormal];
    back.size = back.currentBackgroundImage.size;
    [back bk_addEventHandler:^(id sender) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
}

#pragma mark - 懒加载

- (UIImageView *)imageView {
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ghostbb_lala~"]];
        [self.view addSubview:_imageView];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo((kWindowW-120)/2);
            make.size.mas_equalTo(CGSizeMake(150, 150));
            make.top.mas_equalTo(80);
        }];
    }
    return _imageView;
}


- (UITextField *)userName {
    if (_userName == nil) {
        _userName = [[UITextField alloc] init];
        [self.view addSubview:_userName];
        _userName.borderStyle = UITextBorderStyleRoundedRect;
        [_userName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(30);
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(40);
        }];
    }
    return _userName;
}

- (UITextField *)password {
    if (_password == nil) {
        _password = [[UITextField alloc] init];
        [self.view addSubview:_password];
        _password.secureTextEntry = YES;
        _password.borderStyle = UITextBorderStyleRoundedRect;
        [_password mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_userName.mas_bottom).mas_equalTo(30);
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(40);
            make.right.mas_equalTo(-20);
        }];
    }
    return _password;
}

- (UIButton *)loginButton {
    if (_loginButton == nil) {
        _loginButton = [[UIButton alloc] init];
        _loginButton.backgroundColor = kColor;
        [_loginButton setTitle:@"登录" forState:UIControlStateNormal];
        _loginButton.layer.cornerRadius = 5;
        
        [self.view addSubview:_loginButton];
        [_loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(_password.mas_bottom).mas_equalTo(30);
            make.height.mas_equalTo(40);
        }];
        [_loginButton bk_addEventHandler:^(id sender) {
            [self.view endEditing:YES];
            [BmobUser loginWithUsernameInBackground:self.userName.text password:self.password.text block:^(BmobUser *user, NSError *error) {
                if (error) {
                    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                    hud.mode = MBProgressHUDModeText;
                    hud.labelText = @"登录失败,用户名或密码不正确";
                    [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
                        hud.hidden = YES;
                    } repeats:NO];
                }else {
                    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                    hud.mode = MBProgressHUDModeText;
                    hud.labelText = @"登录成功";
                    [NSTimer bk_scheduledTimerWithTimeInterval:1 block:^(NSTimer *timer) {
                        hud.hidden = YES;
                        [self broadcast:user];
                    } repeats:NO];
                    
                }
            }];
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _loginButton;
}

- (UIButton *)registerButton {
    if (_registerButton == nil) {
        _registerButton = [[UIButton alloc] init];
        [self.view addSubview:_registerButton];
        _registerButton.titleLabel.font = [UIFont systemFontOfSize:14];
        [_registerButton setTitle:@"没有账号?注册账号" forState:UIControlStateNormal];
        [_registerButton setTitleColor:kColor forState:UIControlStateNormal];
        [_registerButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-30);
            make.left.mas_equalTo(30);
            make.top.mas_equalTo(_loginButton.mas_bottom).mas_equalTo(10);
            make.height.mas_equalTo(30);
        }];
        [_registerButton bk_addEventHandler:^(id sender) {
            
            RegisterViewController *registerVC = [[RegisterViewController alloc] init];
            
            [self.navigationController pushViewController:registerVC animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _registerButton;
}


/**
 *  用户处理登录完成后改变 我 里面的个人信息
 *
 *  @param user 登录后的用户信息
 */
- (void)broadcast:(BmobUser *)user {
    // 获取系统提供的通知中心对象
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    // 向通知中心发通知
    // name:通知名称 object：发送方对象是谁（通知是谁发的）
    [center postNotificationName:@"hasLogin" object:nil];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}



@end
