//
//  PofileViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PofileViewController : UITableViewController

@end

@interface  userInfoCell: UITableViewCell

@property (strong, nonatomic) UIImageView *imageV;
@property (strong, nonatomic) UILabel *nikename;
@property (strong, nonatomic) UILabel *desc;

@end
