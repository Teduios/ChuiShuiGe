//
//  LoginNavigationController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/14.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "LoginNavigationController.h"
#import "LoginViewController.h"

@interface LoginNavigationController ()

@end

@implementation LoginNavigationController

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {
        //隐藏底部导航栏
        viewController.hidesBottomBarWhenPushed = YES;
        
        // 设置导航栏的
        UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [leftButton setBackgroundImage:[UIImage imageNamed:@"navigationbar_back_highlighted"] forState:UIControlStateNormal];
        leftButton.size = leftButton.currentBackgroundImage.size;
        [leftButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    }
    
    [super pushViewController:viewController animated:animated];
    
}


- (void)back {
    [self popViewControllerAnimated:YES];
}


- (void)viewDidLoad {
    [super viewDidLoad];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
