//
//  PofileViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "PofileViewController.h"
#import "LoginNavigationController.h"
#import "LoginViewController.h"
#import "SettingViewController.h"
#import "UserInfoViewController.h"
#import "CommonListViewController.h"


@implementation userInfoCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        self.imageV = [[UIImageView alloc] init];
        _imageV.layer.cornerRadius = 30;
        _imageV.layer.masksToBounds = YES;
        [self.contentView addSubview:_imageV];
        [_imageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(60, 60));
        }];
        
        self.nikename = [[UILabel alloc] init];
        _nikename.font = kTitleFont;
        [self.contentView addSubview:_nikename];
        [_nikename mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.left.mas_equalTo(_imageV.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(20);
        }];
        self.desc = [[UILabel alloc] init];
        _desc.font = kCommentFont;
        _desc.textColor = [UIColor grayColor];
        _desc.numberOfLines = 0;
        [self.contentView addSubview:_desc];
        [_desc mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_nikename.mas_bottom).mas_equalTo(0);
            make.leftMargin.mas_equalTo(_nikename.mas_leftMargin);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(40);
        }];
    }
    
    return self;
}


@end

@interface PofileViewController ()


@end

@implementation PofileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我";
    [self.tableView setSeparatorColor:kRGBColor(240, 240, 240)];
    self.view.backgroundColor = kRGBColor(247, 247, 247);
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    self.tableView.tableFooterView = [UIView new];
}
#pragma mark - 懒加载




// 设置通知
- (instancetype)init {
    if (self = [super init]) {
        // 向通知中心注册需要监听某通知
        // addObserver:哪个对象成为观察者  selector:接收到了通知，哪个方法被执行  name：监听哪个通知 object：通知中的其他信息
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataForTableView:) name:@"hasLogin" object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataForTableView:) name:@"LoginOut" object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataForTableView:) name:@"editInfo" object:nil];
    }
    return self;
}



- (void)dealloc
{
    // 移除通知
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


// 登录成功后重新显示 我 的界面
- (void)reloadDataForTableView:(NSNotification *)notification {
    [self.tableView reloadData];
}



- (userInfoCell *)changeLoginCell {
    userInfoCell *infoCell = [[userInfoCell alloc] init];
    BmobUser *current = [BmobUser getCurrentUser];
    if (!current) {
        infoCell.imageV.image = [UIImage imageNamed:@"icon_anonymous"];
        infoCell.nikename.text = @"登录/注册";
        infoCell.desc.text = @"没有账号？快来注册一下快乐吧";
    }else {
        NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[current objectForKey:@"userIcon"]];
        [infoCell.imageV sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
        infoCell.nikename.text = current.username;
        infoCell.desc.text = [current objectForKey:@"desc"];
    }
    
    return infoCell;
}





#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
        case 1:
            return 1;
//        case 2:
        case 2:
            return 1;
        default:
            return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    switch (indexPath.section) {
        case 0:
            cell = [self changeLoginCell];
            break;
        case 1:
            cell.imageView.image = [UIImage imageNamed:@"icon_posted"];
            cell.textLabel.text = @"管理我的帖子";
            cell.imageView.image = [UIImage imageNamed:@"icon_managetie_36-36"];
            break;
//        case 2:
//            if (indexPath.row == 0) {
//                cell.imageView.image = [UIImage imageNamed:@"icon_myfriends"];
//                cell.textLabel.text = @"我的水友/群";
//                cell.imageView.image = [UIImage imageNamed:@"icon_qun_36-36"];
//            }
//            break;
        case 2:
            cell.imageView.image = [UIImage imageNamed:@"icon_shezhi_36-36"];
                cell.textLabel.text = @"设置";
            break;
            
        default:
            break;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 80;
    }else
        return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        BmobUser *user = [BmobUser getCurrentUser];
        if (user) {
            UserInfoViewController *vc = [[UserInfoViewController alloc] init];
            vc.userInfo = user;
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }else {
            LoginNavigationController *nav = [[LoginNavigationController alloc] initWithRootViewController:[LoginViewController new]];
            [self presentViewController:nav animated:YES completion:nil];
        }
    }
    if (indexPath.section == 1) {
        if ([BmobUser getCurrentUser]) {
            CommonListViewController *vc = [[CommonListViewController alloc] init];
            vc.coditionType = ListTypeCondition;
            vc.key = @"author";
            vc.value = [BmobUser getCurrentUser].objectId;
            [self.navigationController pushViewController:vc animated:YES];
        }else {
            LoginNavigationController *nav = [[LoginNavigationController alloc] initWithRootViewController:[LoginViewController new]];
            [self presentViewController:nav animated:YES completion:nil];
        }
        
    }
    if (indexPath.section == 2) {
        SettingViewController *vc = [SettingViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}


@end
