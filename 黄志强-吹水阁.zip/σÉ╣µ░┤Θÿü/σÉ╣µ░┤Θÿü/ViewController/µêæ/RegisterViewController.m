//
//  RegisterViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/14.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()

@property (strong, nonatomic) UIImageView *imageView;

/** 注册用户名 */
@property (strong, nonatomic) UITextField *nikeName;
/** 密码 */
@property (strong, nonatomic) UITextField *password;
/** 注册邮箱 */
@property (strong, nonatomic) UITextField *emailAd;
/** 注册按钮 */
@property (strong, nonatomic) UIButton *registerBtn;
/** 选择性别 */
@property (strong, nonatomic) UISegmentedControl *gender;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kRGBColor(247, 247, 247);
    self.emailAd.placeholder = @"注册的邮箱";
    self.nikeName.placeholder = @"注册用户名";
    self.password.placeholder = @"注册的密码";
    self.registerBtn.hidden = NO;
    self.imageView.hidden = NO;
    self.gender.hidden = NO;
}

#pragma mark - 懒加载
- (UIImageView *)imageView {
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ghostbb_hi~"]];
        [self.view addSubview:_imageView];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo((kWindowW-120)/2);
            make.size.mas_equalTo(CGSizeMake(150, 150));
            make.top.mas_equalTo(80);
        }];
    }
    return _imageView;
}

- (UITextField *)emailAd {
    if (_emailAd == nil) {
        _emailAd = [[UITextField alloc] init];
        _emailAd.borderStyle = UITextBorderStyleRoundedRect;
        [self.view addSubview:_emailAd];
        
        [_emailAd mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(40);
            make.right.mas_equalTo(-20);
        }];
    }
    return _emailAd;
}

- (UITextField *)nikeName {
    if (_nikeName == nil) {
        _nikeName = [[UITextField alloc] init];
        [self.view addSubview:_nikeName];
        _nikeName.borderStyle = UITextBorderStyleRoundedRect;
        [_nikeName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_emailAd.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(40);
            make.right.mas_equalTo(-20);
        }];
    }
    return _nikeName;
}

- (UITextField *)password {
    if (_password == nil) {
        _password = [[UITextField alloc] init];
        [self.view addSubview:_password];
        _password.secureTextEntry = YES;
        _password.borderStyle = UITextBorderStyleRoundedRect;
        [_password mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_nikeName.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(40);
            make.right.mas_equalTo(-20);
        }];
    }
    return _password;
}

- (UISegmentedControl *)gender {
    if (_gender == nil) {
        _gender = [[UISegmentedControl alloc] initWithItems:@[@"男",@"女"]];
        _gender.size = CGSizeMake(200, 30);
        _gender.selectedSegmentIndex = 0;
        _gender.segmentedControlStyle= UISegmentedControlStyleBar;//设置
        _gender.tintColor= kColor;
        [self.view addSubview:_gender];
        [_gender mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-40);
            make.left.mas_equalTo(40);
            make.top.mas_equalTo(_password.mas_bottom).mas_equalTo(20);
            make.height.mas_equalTo(30);
        }];
    }
    return _gender;
}

- (UIButton *)registerBtn {
    if (_registerBtn == nil) {
        _registerBtn = [[UIButton alloc] init];
        _registerBtn.backgroundColor = kColor;
        [_registerBtn setTitle:@"一键注册" forState:UIControlStateNormal];
        _registerBtn.layer.cornerRadius = 5;
        [self.view endEditing:YES];
        [self.view addSubview:_registerBtn];
        [_registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(_password.mas_bottom).mas_equalTo(70);
            make.height.mas_equalTo(40);
        }];
        
        [_registerBtn bk_addEventHandler:^(id sender) {
            [self.view endEditing:YES];
            BmobUser *bUser = [[BmobUser alloc] init];
            [bUser setUsername:self.nikeName.text];
            [bUser setPassword:self.password.text];
            [bUser setObject:@"该用户很赖，没有简介，我猜也没有女朋友" forKey:@"desc"];
            [bUser setObject:@"单身" forKey:@"marriage"];
            [bUser setEmail:self.emailAd.text];
            NSString *genderStr = @"男";
            if (self.gender.selectedSegmentIndex == 1) {
                genderStr = @"女";
            }
            [bUser setObject:genderStr forKey:@"gender"];
            [UIAlertView bk_showAlertViewWithTitle:[NSString stringWithFormat:@"你的性别是 %@",genderStr] message:@"确定吗？此操作不可修改" cancelButtonTitle:@"重新选择" otherButtonTitles:@[@"确定"] handler:^(UIAlertView *alertView, NSInteger buttonIndex) {
                if (buttonIndex == 1) {
                    [bUser signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
                        if (isSuccessful){
                            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                            hud.mode = MBProgressHUDModeText;
                            hud.labelText = @"注册成功,返回登录";
                            [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
                                hud.hidden = YES;
                                [BmobUser logout];
                                [self.navigationController popViewControllerAnimated:YES];
                            } repeats:NO];
                            
                        } else {
                            NSString *err = [NSString stringWithFormat:@"%@",error.userInfo];
                            NSLog(@"%@",err);
                            if ([err rangeOfString:@"nil password"].location != NSNotFound) {
                                err = @"密码为空";
                            }else if ([err rangeOfString:@"email Must be a valid email address"].location != NSNotFound) {
                                err = @"邮箱格式不正确";
                            }else if ([err rangeOfString:@"username"].location != NSNotFound){
                                err = @"用户名重复啊亲";
                            }else if ([err rangeOfString:@"already taken"].location != NSNotFound) {
                                err = @"邮箱已被抢先注册了";
                            }
                            
                            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                            hud.mode = MBProgressHUDModeText;
                            hud.labelText = err;
                            [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
                                hud.hidden = YES;
                            } repeats:NO];
                            
                        }
                    }];
                }
            }];
            
            
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _registerBtn;
}

#pragma mark - 触摸屏幕取消编辑，键盘消失
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}




@end
