//
//  PhotoBrowserViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/23.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoBrowserViewController : UIViewController

/** 图文浏览 */
- (instancetype)initWithPhotoAndText;
/** 纯图浏览 */
- (instancetype)initWithPhoto;

// 图片的地址数组
@property (strong, nonatomic) NSArray *allImagesArr;

// 文字的数组
@property (strong, nonatomic) NSArray *allTextsArr;

@property (strong, nonatomic) NSString *path;

@end
