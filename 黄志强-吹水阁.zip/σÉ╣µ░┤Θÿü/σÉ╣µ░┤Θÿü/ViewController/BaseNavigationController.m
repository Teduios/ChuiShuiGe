//
//  BaseNavigationController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {
        //隐藏底部导航栏
        viewController.hidesBottomBarWhenPushed = YES;
        
        // 设置导航栏的
        UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [leftButton setBackgroundImage:[UIImage imageNamed:@"navigationbar_back_highlighted"] forState:UIControlStateNormal];
        leftButton.size = leftButton.currentBackgroundImage.size;
        [leftButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    }
    
    [super pushViewController:viewController animated:animated];
    
}


- (void)back {
    [self popViewControllerAnimated:YES];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

+ (void)initialize
{
    if (self == [BaseNavigationController class]) {
        // 获取导航条的外观
        UINavigationBar *bar = [UINavigationBar appearance];
//        // 设置背景色
//
//        // 设置背景图
//        [bar setBackgroundImage:[UIImage imageNamed:@"touming"] forBarMetrics:UIBarMetricsDefault];
//        //        [bar setBackgroundColor:[UIColor colorWithHex:0x77777 andAlpha:1]];
//        
//        // 设置左右按钮的文字颜色
//        [bar setTintColor:[UIColor whiteColor]];
//        
//        // 设置标题文字的垂直位置
//        //        [bar setTitleVerticalPositionAdjustment:-20 forBarMetrics:UIBarMetricsDefault];
//        
//        // 设置导航栏的样式，会影响状态栏中文字的颜色
//        [bar setBarStyle:UIBarStyleBlack];
        
        // 设置标题栏文字的样式
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        attributes[NSFontAttributeName] = [UIFont boldSystemFontOfSize:20];
        attributes[NSForegroundColorAttributeName] = kColor;
        [bar setTitleTextAttributes:attributes];
    }
}

@end
