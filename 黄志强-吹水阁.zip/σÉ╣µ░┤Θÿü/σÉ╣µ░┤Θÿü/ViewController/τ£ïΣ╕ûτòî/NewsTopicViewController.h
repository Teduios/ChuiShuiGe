//
//  NewsTopicViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/27.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsTopicViewController : UITableViewController

@property (strong, nonatomic) NSString *path;

@end
