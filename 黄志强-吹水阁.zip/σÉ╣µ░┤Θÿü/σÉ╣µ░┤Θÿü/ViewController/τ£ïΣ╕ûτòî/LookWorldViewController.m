//
//  LookWorldViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "LookWorldViewController.h"
#import "NewsListViewController.h"

@interface LookWorldViewController ()

@end

@implementation LookWorldViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"看世界";
    // Do any additional setup after loading the view.
}

- (instancetype)initWithPageNew {
    if (self = [super init]) {
        self = [[LookWorldViewController alloc] initWithViewControllerClasses:[self itemControllerClass] andTheirTitles:[self itemNames]];
        self.titleColorSelected = kColor;
        self.keys = [self vcKeys];
        self.values = [self vcValues];
    }
    return self;
}

- (NSArray *)itemNames {
    return @[@"头条",@"娱乐",@"时政",@"科技",@"军事"];
}

- (NSArray *)itemControllerClass {
    NSMutableArray *arr = [NSMutableArray array];
    for (int i = 0; i < 5; i++) {
        [arr addObject:[NewsListViewController class]];
    }
    return [arr copy];
}

- (NSArray *)vcKeys {
    NSMutableArray *arr = [NSMutableArray array];
    NSInteger count = [self itemNames].count;
    for (int i = 0; i < count; i++) {
        [arr addObject:@"type"];
    }
    return [arr copy];
}

- (NSArray *)vcValues {
    NSMutableArray *arr = [NSMutableArray array];
    NSInteger count = [self itemNames].count;
    for (int i = 0; i < count; i++) {
        [arr addObject:@(i)];
    }
    return [arr copy];
}

@end
