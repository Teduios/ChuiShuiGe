//
//  NewWebViewController.h
//  吹水阁
//
//  Created by Hanten on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewWebViewController : UIViewController

@property (strong, nonatomic) NSString *url;
@property (strong, nonatomic) NSURL *webURL;

@end
