//
//  NewsTopicViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/27.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsTopicViewController.h"
#import "NewsTopicViewModel.h"
#import "NewsListCell.h"
#import "NewsImageCell.h"
#import "NewWebViewController.h"
#import "PhotoBrowserViewController.h"
#import "iCarousel.h"

@interface NewsTopicViewController ()<iCarouselDelegate,iCarouselDataSource>

@property (strong, nonatomic) NewsTopicViewModel *topicVM;
@property (strong, nonatomic) UILabel *intro;

@end

@implementation NewsTopicViewController
{//添加成员变量,因为不需要懒加载,所以不需要是属性
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[NewsImageCell class] forCellReuseIdentifier:@"NewsImageCell"];
    [self.tableView registerClass:[NewsListCell class] forCellReuseIdentifier:@"NewsListCell"];
    
    self.topicVM.path = self.path;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self.topicVM getDataCompletionHandle:^(NSError *error) {
        if (error) {
            [self showErrorMsg:@"不好意思，出错了(X^X)"];
        }
        [self.tableView reloadData];
        hud.hidden = YES;
        self.tableView.tableHeaderView = [self headerView];
    }];
    self.tableView.tableFooterView = [[UIView alloc] init];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (NewsTopicViewModel *)topicVM {
    if (_topicVM == nil) {
        _topicVM = [[NewsTopicViewModel alloc] init];
    }
    return _topicVM;
}

/** 头部视图 */
- (UIView *)headerView{
    [_timer invalidate];
    // 假如没有头部滚动视图，则返回一个空
    if (![self.topicVM hasHeaderImage]) {
        return nil;
    }
    self.intro = [[UILabel alloc] init];
    self.intro.text = [self.topicVM intro];
    self.intro.numberOfLines = 0;
    CGSize size = [self.intro.text sizeWithFont:self.intro.font maxW:kWindowW-20];
    
    //头部视图origin无效,宽度无效,肯定是与table同宽
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, kWindowW/750 * 500 + size.height+20)];
    //添加底部视图
    UIView *botoomView = [UIView new];
    botoomView.backgroundColor = kRGBColor(240, 240, 240);
    [headView addSubview:botoomView];
    [botoomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
        make.height.mas_equalTo(35);
    }];
    _titleLb = [UILabel new];
    [botoomView addSubview:_titleLb];
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = [self.topicVM headerImages].count;
    [botoomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.centerY.mas_equalTo(0);
        make.width.mas_lessThanOrEqualTo(60);
        make.width.mas_greaterThanOrEqualTo(20);
        make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(-10);
    }];
    _titleLb.text = [self.topicVM headerTitleForRow:0];
    [headView addSubview:self.intro];
    [self.intro mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(size.height+10);
    }];
    //添加滚动栏
    _ic = [iCarousel new];
    [headView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.mas_equalTo(self.intro.mas_bottom).mas_equalTo(0);
        make.bottom.mas_equalTo(botoomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate = self;
    _ic.dataSource = self;
    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    //如果只有一张图,则不显示圆点
    _pageControl.hidesForSinglePage = YES;
    //如果只有一张图,则不可以滚动
    _ic.scrollEnabled = [self.topicVM headerImages].count != 1;
    _pageControl.pageIndicatorTintColor = [UIColor grayColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor blackColor];
    
    if ([self.topicVM headerImages].count > 1) {
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    }
    //小圆点 不能与用户交互
    _pageControl.userInteractionEnabled = NO;
    return headView;
}
#pragma mark - iCarousel Delegate
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [self.topicVM headerImages].count;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750 * 500 - 35)];
        UIImageView *imageView = [UIImageView new];
        [view addSubview:imageView];
        imageView.tag = 100;
        imageView.contentMode = 2;
        view.clipsToBounds = YES;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    [imageView sd_setImageWithURL:[self.topicVM headerImages][index] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
    return view;
}

/** 允许循环滚动 */
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}

/** 监控当前滚到到第几个 */
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    NSInteger index = carousel.currentItemIndex;
    _titleLb.text = [self.topicVM headerTitleForRow:index];
    _pageControl.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {
    
    PhotoBrowserViewController *photoVC = [[PhotoBrowserViewController alloc] init];
    photoVC.path = [self.topicVM headerURLForRow:index];
    [self.navigationController pushViewController:photoVC animated:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger count = self.topicVM.sectionNumber;
    return count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.topicVM subjectsModelForSectionInRow:section].podItems.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

        NewsListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsListCell" forIndexPath:indexPath];
        cell.titleLb.text = [self.topicVM titleWithSection:indexPath.section ForRow:indexPath.row];
        cell.dateLb.hidden = YES;
        [cell.comment setTitle:[self.topicVM dateWithSection:indexPath.section ForRow:indexPath.row] forState:UIControlStateNormal];
        if ([self.topicVM isHadImageWithSection:indexPath.section ForRow:indexPath.row]) {
            cell.iconView.hidden = NO;
            [cell.titleLb mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(cell.iconView.mas_right).mas_equalTo(10);
                make.top.mas_equalTo(10);
                make.right.mas_equalTo(-10);
                make.height.mas_equalTo(45);
            }];
            [cell.iconView.imageView sd_setImageWithURL:[self.topicVM imageWithSection:indexPath.section ForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
            
        }else {
            cell.iconView.hidden = YES;
            [cell.titleLb mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(10);
                make.top.mas_equalTo(10);
                make.right.mas_equalTo(-10);
                make.height.mas_equalTo(45);
            }];
            
        }
        return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return [self.topicVM headerTitleForSection:section];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 85;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *typeStr = [self.topicVM typeWithSection:indexPath.section ForRow:indexPath.row];
    if ([typeStr isEqualToString:@"doc"] && ![self.topicVM isHadSlideWithSection:indexPath.section ForRow:indexPath.row]) {
        NewWebViewController *vc = [[NewWebViewController alloc] init];
        vc.url = [self.topicVM detailURLWithSection:indexPath.section ForRow:indexPath.row];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if ([typeStr isEqualToString:@"slide"] || [self.topicVM isHadSlideWithSection:indexPath.section ForRow:indexPath.row]) {
        PhotoBrowserViewController *photoVC = [[PhotoBrowserViewController alloc] init];
        photoVC.path = [self.topicVM detailURLWithSection:indexPath.section ForRow:indexPath.row];
        [self.navigationController pushViewController:photoVC animated:YES];
    }else if ([typeStr isEqualToString:@"topic2"]) {
        NewsTopicViewController *topicVC = [[NewsTopicViewController alloc] init];
        topicVC.path = [self.topicVM detailURLWithSection:indexPath.section ForRow:indexPath.row];
        [self.navigationController pushViewController:topicVC animated:YES];
    }else {
        [self showErrorMsg:@"不好意思，暂无法查看内容"];
    }
}



@end
