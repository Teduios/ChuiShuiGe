//
//  NewsListViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewsListViewController.h"
#import "NewsListCell.h"
#import "NewsImageCell.h"
#import "iCarousel.h"
#import "NewWebViewController.h"
#import "PhotoBrowserViewController.h"
#import "NewsTopicViewController.h"



@interface NewsListViewController ()<iCarouselDelegate,iCarouselDataSource>

@property (strong, nonatomic) NewsViewModel *newsVM;

@end

@implementation NewsListViewController
{//添加成员变量,因为不需要懒加载,所以不需要是属性
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLb;
    NSTimer *_timer;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.newsVM.type = self.type;
    [self.tableView registerClass:[NewsImageCell class] forCellReuseIdentifier:@"NewsImageCell"];
    [self.tableView registerClass:[NewsListCell class] forCellReuseIdentifier:@"NewsListCell"];
    __weak typeof(self) headerVC = self;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [headerVC.newsVM refreshDataCompletionHandle:^(NSError *error) {
            [headerVC.tableView.mj_header endRefreshing];
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            dispatch_async(dispatch_get_main_queue(), ^{
                [headerVC.tableView reloadData];
                headerVC.tableView.tableHeaderView = [headerVC headerView];
            });
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [headerVC.newsVM getMoreDataCompletionhandle:^(NSError *error) {
            [headerVC.tableView.mj_footer endRefreshing];
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            dispatch_async(dispatch_get_main_queue(), ^{
                [headerVC.tableView reloadData];
            });
        }];
    }];
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

#pragma mark - 懒加载
- (NewsViewModel *)newsVM {
    if (_newsVM == nil) {
        _newsVM = [[NewsViewModel alloc] init];
    }
    return _newsVM;
}




/** 头部滚动视图 */
- (UIView *)headerView{
    [_timer invalidate];
    // 假如没有头部滚动视图，则返回一个空
    if (![self.newsVM hasHeaderImage]) {
        return nil;
    }
    //头部视图origin无效,宽度无效,肯定是与table同宽
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, kWindowW/750 * 500)];
    //添加底部视图
    UIView *botoomView = [UIView new];
    botoomView.backgroundColor = kRGBColor(240, 240, 240);
    [headView addSubview:botoomView];
    [botoomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
        make.height.mas_equalTo(35);
    }];
    _titleLb = [UILabel new];
    [botoomView addSubview:_titleLb];
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = [self.newsVM headerImages].count;
    [botoomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.centerY.mas_equalTo(0);
        make.width.mas_lessThanOrEqualTo(60);
        make.width.mas_greaterThanOrEqualTo(20);
        make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(-10);
    }];
    _titleLb.text = [self.newsVM headerTitleForRow:0];
    //添加滚动栏
    _ic = [iCarousel new];
    [headView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_equalTo(0);
        make.bottom.mas_equalTo(botoomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate = self;
    _ic.dataSource = self;
    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    //如果只有一张图,则不显示圆点
    _pageControl.hidesForSinglePage = YES;
    //如果只有一张图,则不可以滚动
    _ic.scrollEnabled = [self.newsVM headerImages].count != 1;
    _pageControl.pageIndicatorTintColor = [UIColor grayColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor blackColor];
    
    if ([self.newsVM headerImages].count > 1) {
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    }
    //小圆点 不能与用户交互
    _pageControl.userInteractionEnabled = NO;
    return headView;
}
#pragma mark - iCarousel Delegate
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [self.newsVM headerImages].count;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750 * 500 - 35)];
        UIImageView *imageView = [UIImageView new];
        [view addSubview:imageView];
        imageView.tag = 100;
        imageView.contentMode = 2;
        view.clipsToBounds = YES;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    [imageView sd_setImageWithURL:[self.newsVM headerImages][index] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
    return view;
}

/** 允许循环滚动 */
- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}

/** 监控当前滚到到第几个 */
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    _titleLb.text = [self.newsVM headerTitleForRow:carousel.currentItemIndex];
    _pageControl.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {

    PhotoBrowserViewController *photoVC = [[PhotoBrowserViewController alloc] init];
    photoVC.path = [self.newsVM headerURLForRow:index];
    [self.navigationController pushViewController:photoVC animated:YES];
}


#pragma mark - Table view data source

kRemoveCellSeparator
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.newsVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.newsVM isImagesForRow:indexPath.row]) {
        NewsImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsImageCell" forIndexPath:indexPath];
        cell.titleLb.text = [self.newsVM titleForRow:indexPath.row];
        [cell.image1.imageView sd_setImageWithURL:[self.newsVM imagesForRow:indexPath.row][0] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
        [cell.image2.imageView sd_setImageWithURL:[self.newsVM imagesForRow:indexPath.row][1] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
        [cell.image3.imageView sd_setImageWithURL:[self.newsVM imagesForRow:indexPath.row][2] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
        cell.dateLb.text = [self.newsVM dateForRow:indexPath.row];
        [cell.comment setTitle:[self.newsVM commentsForRow:indexPath.row] forState:UIControlStateNormal];
        
        return cell;
    }else {
        NewsListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsListCell" forIndexPath:indexPath];
        cell.titleLb.text = [self.newsVM titleForRow:indexPath.row];
        if ([[self.newsVM typeForRow:indexPath.row] isEqualToString:@"topic2"]) {
            cell.dateLb.hidden = NO;
        }else {
            cell.dateLb.hidden = YES;
        }
        [cell.comment setTitle:[self.newsVM dateForRow:indexPath.row] forState:UIControlStateNormal];
        if ([self.newsVM isHadImageForRow:indexPath.row]) {
            cell.iconView.hidden = NO;
            [cell.titleLb mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(cell.iconView.mas_right).mas_equalTo(10);
                make.top.mas_equalTo(10);
                make.right.mas_equalTo(-10);
                make.height.mas_equalTo(45);
            }];
            [cell.iconView.imageView sd_setImageWithURL:[self.newsVM imageForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
            
            
        }else {
            cell.iconView.hidden = YES;
            [cell.titleLb mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(10);
                make.top.mas_equalTo(10);
                make.right.mas_equalTo(-10);
                make.height.mas_equalTo(45);
            }];
            
        }
        return cell;
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.newsVM isImagesForRow:indexPath.row]) {
        return 75 + (kWindowW - 30)/3 * 0.65;
    }else {
        return 86;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *typeStr = [self.newsVM typeForRow:indexPath.row];
    if ([typeStr isEqualToString:@"doc"]) {
        NewWebViewController *vc = [[NewWebViewController alloc] init];
        vc.url = [self.newsVM detailURLForRow:indexPath.row];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if ([typeStr isEqualToString:@"slide"]) {
        PhotoBrowserViewController *photoVC = [[PhotoBrowserViewController alloc] init];
        photoVC.path = [self.newsVM detailURLForRow:indexPath.row];
        [self.navigationController pushViewController:photoVC animated:YES];
    }else if ([typeStr isEqualToString:@"topic2"]) {
        NewsTopicViewController *topicVC = [[NewsTopicViewController alloc] init];
        topicVC.path = [self.newsVM detailURLForRow:indexPath.row];
        [self.navigationController pushViewController:topicVC animated:YES];
    }else {
        [self showErrorMsg:@"不好意思，没有内容"];
    }
    
    
    
}


#pragma mark - 检查是否销毁
- (void)dealloc {
    NSLog(@"NewsListViewController 销毁了");
}




@end
