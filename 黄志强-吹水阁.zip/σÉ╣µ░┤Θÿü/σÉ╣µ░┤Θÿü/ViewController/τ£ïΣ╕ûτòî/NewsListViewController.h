//
//  NewsListViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/17.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsViewModel.h"

@interface NewsListViewController : UITableViewController

@property (nonatomic) NewsType type;

@end
