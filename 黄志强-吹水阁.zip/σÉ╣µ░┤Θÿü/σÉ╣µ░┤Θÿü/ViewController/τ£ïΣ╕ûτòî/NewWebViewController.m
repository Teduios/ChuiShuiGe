//
//  NewWebViewController.m
//  吹水阁
//
//  Created by Hanten on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "NewWebViewController.h"
#import "NewsDetailViewModel.h"

@interface NewWebViewController ()<UIWebViewDelegate>

@property (strong, nonatomic) UIWebView *webView;
@property (strong, nonatomic) NewsDetailViewModel *detailVM;

@end

@implementation NewWebViewController

#pragma mark - 懒加载

- (UIWebView *)webView {
    if (_webView == nil) {
        _webView = [[UIWebView alloc] init];
        [self.view addSubview:_webView];
        _webView.delegate = self;
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.top.mas_equalTo(0);
        }];
        
    }
    return _webView;
}

- (NewsDetailViewModel *)detailVM {
    if (_detailVM == nil) {
        _detailVM = [[NewsDetailViewModel alloc] init];
        _detailVM.path = self.url;
    }
    return _detailVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.extendedLayoutIncludesOpaqueBars = NO;
    self.edgesForExtendedLayout = UIRectEdgeBottom | UIRectEdgeLeft | UIRectEdgeRight;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"新闻详情";
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self.detailVM getDataCompletionHandle:^(NSError *error) {
        hud.hidden = YES;
        [self.webView loadHTMLString:[self.detailVM content] baseURL:[self.detailVM wapURL]];
    }];

    
}




- (void)webViewDidStartLoad:(UIWebView *)webView {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];

}


#pragma mark - 检查是否销毁
- (void)dealloc {
    NSLog(@"NewWebViewController 销毁了");
}




@end
