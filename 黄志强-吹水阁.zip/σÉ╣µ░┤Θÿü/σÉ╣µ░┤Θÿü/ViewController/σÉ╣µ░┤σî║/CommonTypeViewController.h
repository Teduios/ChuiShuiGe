//
//  CommonListViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "WMPageController.h"


@interface CommonTypeViewController : WMPageController


- (instancetype)initWithClickType:(ClickType)clickType;

@end
