//
//  CommonListViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommonTypeViewController.h"
#import "CommonListViewController.h"
#import "PostViewController.h"
#import "LoginNavigationController.h"
#import "LoginViewController.h"

@interface CommonTypeViewController ()

@end

@implementation CommonTypeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (instancetype)initWithClickType:(ClickType)clickType {
    if (self = [super init]) {
        self = [[CommonTypeViewController alloc] initWithViewControllerClasses:[self itemControllerClass] andTheirTitles:[self ItemNamesWithClickType:clickType]];
        self.titleColorSelected = kColor;
        self.menuViewStyle = WMMenuViewStyleLine;
        self.keys = [self vcKeysWithClickType:clickType];
        self.values = [self vcValuesWithClickType:clickType];
        
        // 设置导航栏发帖按钮
        UIButton *addTie = [UIButton new];
        [addTie setBackgroundImage:[UIImage imageNamed:@"navigationbar_compose_highlighted"] forState:UIControlStateNormal];
        addTie.size = addTie.currentBackgroundImage.size;
        [addTie bk_addEventHandler:^(id sender) {
            if ([BmobUser getCurrentUser].username.length > 0) {
                PostViewController *postVC = [[PostViewController alloc] init];
                postVC.type = clickType;
                postVC.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:postVC animated:YES];
            }else {
                LoginNavigationController *nav = [[LoginNavigationController alloc] initWithRootViewController:[LoginViewController new]];
                [self presentViewController:nav animated:YES completion:nil];
            }
            
        } forControlEvents:UIControlEventTouchUpInside];
        switch (clickType) {
            case ClickTypeMix: {
                self.title = @"男女大乱斗";
                break;
            }
            case ClickTypeMan: {
                self.title = @"屌丝乱战";
                break;
            }
            case ClickTypeWomen: {
                self.title = @"后宫佳丽";
                break;
            }
            default: {
                break;
            }
        }
        
        
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:addTie];
        
        
        
        
        
    }
    return self;
}

- (NSArray *)ItemNamesWithClickType:(ClickType)type {
    switch (type) {
        case ClickTypeMix: {
            return @[@"最新",@"吹水区"];
        }
        case ClickTypeMan: {
            return @[@"最新",@"游戏"];
        }
        case ClickTypeWomen: {
            return @[@"最新",@"化妆"];
        }
    }
}

- (NSArray *)itemControllerClass {
    NSMutableArray *arr = [NSMutableArray array];
    for (int i = 0; i < 2; i++) {
        [arr addObject:[CommonListViewController class]];
    }
    return [arr copy];
}

- (NSArray *)vcKeysWithClickType:(ClickType)type {
    
    return @[@"sectionType",@"sectionType"];
}

- (NSArray *)vcValuesWithClickType:(ClickType)type {
    return @[@(type),@(type)];
}

@end
