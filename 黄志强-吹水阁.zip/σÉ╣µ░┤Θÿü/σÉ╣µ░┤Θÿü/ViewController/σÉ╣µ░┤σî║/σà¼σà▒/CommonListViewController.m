//
//  CommonListViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommonListViewController.h"
#import "CommonListCell.h"
#import "PostViewController.h"
#import "UserInfoViewController.h"
#import "CommonDetailViewController.h"

@interface CommonListViewController ()

@property (strong, nonatomic) ListViewModel *listVM;

@end

@implementation CommonListViewController

- (instancetype)initWithStyle:(UITableViewStyle)style {
    if (self = [super initWithStyle:UITableViewStyleGrouped]) {
        
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.listVM.sectionType = self.sectionType;
    self.listVM.type = self.coditionType;
    self.listVM.key = self.key;
    self.listVM.value = self.value;
    self.tableView.backgroundColor = kRGBColor(247, 247, 247);
    [self.tableView registerClass:[CommonListCell class] forCellReuseIdentifier:@"ListCell"];
    self.tableView.tableFooterView = [UIView new];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.listVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView.mj_header endRefreshing];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }];
    }];
    
    [self.tableView.mj_header beginRefreshing];
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.listVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }else{
                [self.tableView.mj_footer endRefreshing];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.tableView reloadData];
                });
            }
        }];
    }];
}

#pragma mark - 懒加载
- (ListViewModel *)listVM {
    if (_listVM == nil) {
        _listVM = [[ListViewModel alloc] init];
    }
    return _listVM;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.listVM.rowNumber;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CommonListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ListCell" forIndexPath:indexPath];
    [cell.userIcon.imageView sd_setImageWithURL:[self.listVM userIconForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
    
    __weak typeof(self) listVC = self;
    [cell.userIcon.imageButton bk_removeEventHandlersForControlEvents:UIControlEventTouchUpInside];
    [cell.userIcon.imageButton bk_addEventHandler:^(id sender) {
        UserInfoViewController *userInfoVC = [[UserInfoViewController alloc] init];
        userInfoVC.hidesBottomBarWhenPushed = YES;
        userInfoVC.userInfo = [listVC.listVM authorForRow:indexPath.section];
        [listVC.navigationController pushViewController:userInfoVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.nikeName.text = [self.listVM userNikeNameForRow:indexPath.section];
    cell.createDate.text = [self.listVM createTimeForRow:indexPath.section];
    
    cell.titleLb.text = [self.listVM titleForRow:indexPath.section];
    cell.contentLb.text =  [self.listVM contentForRow:indexPath.section];
    
    if ([self.listVM isHadPicForRow:indexPath.section]) {
        /**
         *  每次调用都移除原有的子控件
         */
        for(UIView *view in [cell.allImagesView subviews])
        {
            [view removeFromSuperview];
        }
        
        CustomImageView *imageView = [[CustomImageView alloc] init];
        imageView.frame = CGRectMake(10, 0, 100, 100);
        [imageView.imageView sd_setImageWithURL:[self.listVM allImagesForRow:indexPath.section][0] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
        [cell.allImagesView addSubview:imageView];
        [cell.allImagesView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(cell.contentLb.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(100);
            make.bottom.mas_equalTo(-10);
        }];
    }else {
        /**
         *  每次调用都移除原有的子控件
         */
        for(UIView *view in [cell.allImagesView subviews])
        {
            [view removeFromSuperview];
        }
        
        [cell.allImagesView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(cell.contentLb.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(0);
            make.bottom.mas_equalTo(-4);
        }];
    }
    

    
    return cell;
}
kRemoveCellSeparator

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 5;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    CommonDetailViewController *detailVC = [[CommonDetailViewController alloc] init];
    detailVC.userInfo = [self.listVM authorForRow:indexPath.section];
    detailVC.post = [self.listVM postModelForRow:indexPath.section];
    detailVC.sectionType = self.sectionType;
    detailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detailVC animated:YES];
    
    
}


#pragma mark - 检查是否销毁
- (void)dealloc {
    NSLog(@"CommonListViewController销毁了");
}



@end
