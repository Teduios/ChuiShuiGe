//
//  FreeChatViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "FreeChatViewController.h"
#import "MixDoubleCell.h"
#import "SeparateCell.h"
#import "CommonTypeViewController.h"
#import "CommonListViewController.h"

#define kSectionCount 2   // 分区

@interface FreeChatViewController ()

@end

@implementation FreeChatViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"吹水大世界";
    self.tableView.backgroundColor = [UIColor whiteColor];
    
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return kSectionCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        MixDoubleCell *cell = [[MixDoubleCell alloc] init];
        [cell.goBtn bk_addEventHandler:^(id sender) {
            CommonTypeViewController *vc = [[CommonTypeViewController alloc] initWithClickType:ClickTypeMix];
            [self.navigationController pushViewController:vc animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        return cell;
    }else {
        SeparateCell *cell = [[SeparateCell alloc] init];
        [cell.goManBtn bk_addEventHandler:^(id sender) {
            if ([[[BmobUser getCurrentUser] objectForKey:@"gender"] isEqualToString:@"男"]) {
                CommonTypeViewController *vc = [[CommonTypeViewController alloc] initWithClickType:ClickTypeMan];
                [self.navigationController pushViewController:vc animated:YES];
            }else {
                MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                hub.mode = MBProgressHUDModeText;
                hub.labelText = @"怎么能随意偷窥男生小秘密呢😳";
                [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
                    hub.hidden = YES;
                } repeats:NO];
            }
            
        } forControlEvents:UIControlEventTouchUpInside];
        
        [cell.goWomenBtn bk_addEventHandler:^(id sender) {
            if ([[[BmobUser getCurrentUser] objectForKey:@"gender"] isEqualToString:@"女"]) {
                CommonTypeViewController *vc = [[CommonTypeViewController alloc] initWithClickType:ClickTypeWomen];
                [self.navigationController pushViewController:vc animated:YES];
            }else {
                MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                hub.mode = MBProgressHUDModeCustomView;
                hub.labelText = @"人家的小秘密怎么能让你看到呢";
                [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
                    hub.hidden = YES;
                } repeats:NO];
            }
            
        } forControlEvents:UIControlEventTouchUpInside];
        return cell;
    }
}


- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}
/** 取消点中高亮状态 */
- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}


@end
