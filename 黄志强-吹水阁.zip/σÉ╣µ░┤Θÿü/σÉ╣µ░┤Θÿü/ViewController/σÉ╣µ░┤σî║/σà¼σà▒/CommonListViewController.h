//
//  CommonListViewController.h
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListViewModel.h"
@interface CommonListViewController : UITableViewController

@property (nonatomic) ListType coditionType;
@property (strong, nonatomic) NSString *key;
@property (strong, nonatomic) id value;
@property (nonatomic) ClickType sectionType;

@end
