//
//  EditUserInfoViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/18.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "EditUserInfoViewController.h"
#import "HZAreaPickerView.h"
@interface EditUserInfoViewController ()<UITextFieldDelegate, HZAreaPickerDelegate, HZAreaPickerDatasource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>

@property (strong, nonatomic) UIImageView *imageV;            // 选取图片
@property (nonatomic) BOOL mark;                              // 是否选择照片的标志
@property (strong, nonatomic) UITextField *areaText;          // 地区选择
@property (strong, nonatomic) UITextField *username;          // 用户名
@property (strong, nonatomic) UITextField *age;               // 年龄
@property (strong, nonatomic) UISegmentedControl *marriage;   // 情感状态
@property (strong, nonatomic) UITextView *desc;               // 个人描述
@property (strong, nonatomic) NSString *areaValue;            // 地区的数据
@property (strong, nonatomic) HZAreaPickerView *locatePicker; // 地区选择器


@end

@implementation EditUserInfoViewController
{
    BmobEvent *_bmobEvent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mark = NO;
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    self.tableView.tableFooterView = self.desc;
    
    self.navigationItem.title = @"编辑个人资料";
    
    UIButton *saveBtn = [[UIButton alloc] init];
    saveBtn.frame = CGRectMake(0, 0, 60, 30);
    [saveBtn setTitle:@"保存" forState:UIControlStateNormal];
    saveBtn.titleLabel.font = kNaviFont;
    [saveBtn setTitleColor:kColor forState:UIControlStateNormal];
    saveBtn.layer.cornerRadius = 4;
    [saveBtn addTarget:self action:@selector(saveInfo) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:saveBtn];
    
}

#pragma mark - 懒加载

- (UIImageView *)imageV {
    if (_imageV == nil) {
        _imageV = [[UIImageView alloc] init];
        _imageV.frame = CGRectMake(0, 0, 50, 50);
        _imageV.layer.cornerRadius = 25;
        _imageV.layer.masksToBounds = YES;
        _imageV.backgroundColor = [UIColor brownColor];
        NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[[BmobUser getCurrentUser] objectForKey:@"userIcon"]];
        [_imageV sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
    }
    return _imageV;
}

- (UITextField *)areaText {
    if (_areaText == nil) {
        _areaText = [[UITextField alloc] init];
        _areaText.borderStyle = UITextBorderStyleRoundedRect;
        _areaText.frame = CGRectMake(0, 0, 200, 30);
        _areaText.text = [[BmobUser getCurrentUser] objectForKey:@"address"];
        _areaText.delegate = self;
    }
    return _areaText;
}

- (UITextField *)age {
    if (_age == nil) {
        _age = [[UITextField alloc] init];
        _age.borderStyle = UITextBorderStyleRoundedRect;
        _age.frame = CGRectMake(0, 0, 200, 30);
        _age.text = [NSString stringWithFormat:@"%@",[[BmobUser getCurrentUser] objectForKey:@"age"]];
    }
    return _age;
}

- (UITextField *)username {
    if (_username == nil) {
        _username = [[UITextField alloc] init];
        _username.borderStyle = UITextBorderStyleRoundedRect;
        _username.frame = CGRectMake(0, 0, 200, 30);
        _username.text = [BmobUser getCurrentUser].username;
    }
    return _username;
}

- (UISegmentedControl *)marriage {
    if (_marriage == nil) {
        _marriage = [[UISegmentedControl alloc] initWithItems:@[@"单身",@"恋爱中",@"已婚"]];
        _marriage.size = CGSizeMake(200, 30);
        _marriage.selectedSegmentIndex = 0;
        _marriage.segmentedControlStyle= UISegmentedControlStyleBar;//设置
        _marriage.tintColor= kColor;
        
        if ([[[BmobUser getCurrentUser] objectForKey:@"marriage"] isEqualToString:@"恋爱中"]) {
            _marriage.selectedSegmentIndex = 1;
        }else if ([[[BmobUser getCurrentUser] objectForKey:@"marriage"] isEqualToString:@"已婚"]) {
            _marriage.selectedSegmentIndex = 2;
        }
        
    }
    return _marriage;
}

- (UITextView *)desc {
    if (_desc == nil) {
        _desc = [[UITextView alloc] init];
        _desc.layer.borderWidth = 2;
        _desc.layer.borderColor = kColor.CGColor;
        _desc.layer.cornerRadius = 4;
        _desc.layer.masksToBounds = YES;
        _desc.frame = CGRectMake(0, 0, 0, 150);
        _desc.text = [[BmobUser getCurrentUser] objectForKey:@"desc"];
    }
    return _desc;
}



-(void)setAreaValue:(NSString *)areaValue
{
    if (![_areaValue isEqualToString:areaValue]) {
        self.areaText.text = areaValue;
    }
}


- (void)viewDidUnload
{
    [self setAreaText:nil];
    [self cancelLocatePicker];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"Cell"];
    if (indexPath.section == 0) {
        cell.textLabel.text = @"头像";
        cell.accessoryView = self.imageV;
    }else {
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = @"昵称";
                cell.accessoryView = self.username;
                break;
            case 1:
                cell.textLabel.text = @"年龄";
                cell.accessoryView = self.age;
                break;
            case 2:
                cell.textLabel.text = @"地址";
                cell.accessoryView = self.areaText;
                break;
            case 3:
                cell.textLabel.text = @"情感状态";
                cell.accessoryView = self.marriage;
                break;
            case 4:
                cell.textLabel.text = @"个人描述";
                break;
                
            default:
                break;
        }
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 60;
    }else {
        return 44;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        /** 选择头像的来源 相册/拍照 */
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"从相册选取" otherButtonTitles:@"拍照选取", nil];
        [actionSheet showInView:self.view];
        
    }else if (indexPath.section == 1) {
        [self cancelEditAddress];
    }
}
#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSLog(@"buttonindex:%ld",buttonIndex);
    UIImagePickerController *pc = [[UIImagePickerController alloc] init];
    pc.delegate = self;
    // 开启编辑功能
    pc.allowsEditing = YES;
    // 可以定义要选取的数据类型，默认只显示图片
    pc.mediaTypes = @[(NSString *)kUTTypeMovie,(NSString *)kUTTypeImage];
    
    if (buttonIndex == 0) {
        [self presentViewController:pc animated:YES completion:nil];
    }else if (buttonIndex == 1) {
        // 选择输入源的类型为拍照，默认只是相册
        pc.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:pc animated:YES completion:nil];
    }else {
        return;
    }
    
}


#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    /**
     *  通过断点来查询到info的字典属性
     */
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    self.imageV.image = image;
    self.mark = YES;
    if (image.size.width > 100) {
        CGFloat bili = image.size.height * 1.0 / image.size.width;
        CGFloat height = 100 * bili;
        self.imageV.image = [Factory imageCompressForSize:image targetSize:CGSizeMake(100, height)];
    }else {
        self.imageV.image = [Factory imageCompressForSize:image targetSize:image.size];
    }
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}



#pragma mark - HZAreaPicker delegate
-(void)pickerDidChaneStatus:(HZAreaPickerView *)picker
{
    self.areaValue = [NSString stringWithFormat:@"%@ %@ %@", picker.locate.state, picker.locate.city, picker.locate.district];
}

-(NSArray *)areaPickerData:(HZAreaPickerView *)picker
{
    NSArray *data;
    data = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"area" ofType:@"plist"]];
    return data;
}



- (void)cancelLocatePicker
{
    [self.locatePicker cancelPicker];
    self.locatePicker.delegate = nil;
    self.locatePicker = nil;
}


#pragma mark - TextField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [self.view endEditing:YES];
    if ([textField isEqual:self.areaText]) {
        [self cancelLocatePicker];
        
        self.locatePicker = [[HZAreaPickerView alloc] initWithStyle:HZAreaPickerWithStateAndCityAndDistrict
                                                       withDelegate:self
                                                      andDatasource:self];
        [self.locatePicker showInView:self.view];
    } else {
        [self cancelLocatePicker];
        self.locatePicker = [[HZAreaPickerView alloc] initWithStyle:HZAreaPickerWithStateAndCity
                                                       withDelegate:self
                                                      andDatasource:self];
        [self.locatePicker showInView:self.view];
    }
    return NO;
}


- (void)cancelEditAddress {
    [self.view endEditing:YES];
    [self cancelLocatePicker];
}


#pragma mark - 保存资料

- (void)saveInfo {
    [self.view endEditing:YES];
    
    BmobObject *bmobObject = [BmobObject objectWithoutDatatWithClassName:@"_User"  objectId:[BmobUser getCurrentUser].objectId];
    
    [bmobObject setObject:self.username.text forKey:@"username"];
    [bmobObject setObject:self.areaText.text forKey:@"address"];
    NSInteger ageNB = self.age.text.integerValue;
    [bmobObject setObject:@(ageNB) forKey:@"age"];
    NSString *marriageStr = @"单身";
    if (self.marriage.selectedSegmentIndex == 1) {
        marriageStr = @"恋爱中";
    }else if (self.marriage.selectedSegmentIndex == 2){
        marriageStr = @"已婚";
    }
    [bmobObject setObject:marriageStr forKey:@"marriage"];
    [bmobObject setObject:self.desc.text forKey:@"desc"];
    if (self.mark) {
        NSString *imgFileName = [NSString stringWithFormat:@"%@.jpg",[BmobUser getCurrentUser].objectId];
        NSData *data = [[NSData alloc] init];
        data = UIImagePNGRepresentation(self.imageV.image);
        [BmobProFile uploadFileWithFilename:imgFileName fileData:data block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
            if (isSuccessful) {
                //设置帖子的图片
                [bmobObject setObject:url forKey:@"userIcon"];
                
                [bmobObject updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                    if (isSuccessful) {
                        //修改成功后的动作
                        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                        hud.mode = MBProgressHUDModeText;
                        hud.labelText = @"修改资料成功,你现在需要重新登录";
                        [NSTimer bk_scheduledTimerWithTimeInterval:1 block:^(NSTimer *timer) {
                            hud.hidden = YES;
                            [BmobUser logout];
                            NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
                            [center postNotificationName:@"editInfo" object:nil];
                            [self.navigationController popToRootViewControllerAnimated:YES];
                        } repeats:NO];
                        
                    } else if (error){
                        [self showErrorMsg:@"用户已存在"];
                    } else {
                        [self showErrorMsg:@"未知错误"];
                    }
                }];
                
            } else {
                if (error) {
                    [self showErrorMsg:@"网络错误"];
                }
            }
        } progress:^(CGFloat progress) {
            //上传进度，此处可编写进度条逻辑
            [self showProgress];
        }];
    }else {
        // 将修改的内容上传服务器，进行修改
        [bmobObject updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (isSuccessful) {
                //修改成功后的动作
                MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                hud.mode = MBProgressHUDModeText;
                hud.labelText = @"修改资料成功,你现在需要重新登录";
                [NSTimer bk_scheduledTimerWithTimeInterval:1 block:^(NSTimer *timer) {
                    hud.hidden = YES;
                    [BmobUser logout];
                    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
                    [center postNotificationName:@"editInfo" object:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                } repeats:NO];
            } else if (error){
                [self showErrorMsg:@"用户名已存在"];
            } else {
                [self showErrorMsg:@"未知错误"];
            }
        }];
    }
    
}




@end
