//
//  UserInfoViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/18.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "UserInfoViewController.h"
#import "CommonListViewController.h"
#import "TrendCell.h"
#import "EditUserInfoViewController.h"


@interface UserInfoViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (copy, nonatomic) NSString *lateTitle;
@property (copy, nonatomic) NSString *lateContent;
@property (copy, nonatomic) NSString *trendCount;
@property (copy, nonatomic) NSURL *imageURL;
@property (nonatomic) BOOL isHasImage;
@property (nonatomic) BOOL mark;
@property (strong, nonatomic) UITableView *tableView;

@end

@implementation UserInfoViewController
{
    UIImageView *navBarHairlineImageView;
}

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.frame = CGRectMake(0, -64, kWindowW, kWindowH);
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    
    self.mark = YES;
    self.isHasImage = YES;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.tableHeaderView = [self headerView];
    UIButton *editBtn = [[UIButton alloc] init];
    editBtn.frame = CGRectMake(0, 0, 60, 30);
    [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [editBtn setTitleColor:kColor forState:UIControlStateNormal];
    editBtn.titleLabel.font = kNaviFont;
    editBtn.layer.cornerRadius = 4;
    [editBtn bk_addEventHandler:^(id sender) {
        EditUserInfoViewController *vc = [[EditUserInfoViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    if ([self.userInfo.objectId isEqualToString:[BmobUser getCurrentUser].objectId]) {
         self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:editBtn];
    }
    
}


- (UIImageView *)findHairlineImageViewUnder:(UIView *)view {
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0) {
        return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // 设置导航栏透明
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"touming"] forBarMetrics:UIBarMetricsDefault];
    navBarHairlineImageView = [self findHairlineImageViewUnder:self.navigationController.navigationBar];
    navBarHairlineImageView.hidden = YES;
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self getUserInfo];
        [self.tableView reloadData];
    });
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    navBarHairlineImageView.hidden = NO;
    [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@""] forBarMetrics:UIBarMetricsDefault];
}


// 头部视图
- (UIView *)headerView {
    UIView *headerView = [[UIView alloc] init];
    headerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"user_bg.jpg"]];
    headerView.frame = CGRectMake(0, 0, kWindowW, 250);
    CustomImageView *iconView = [[CustomImageView alloc] init];
    NSString *imageURL = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[self.userInfo objectForKey:@"userIcon"]];
    [iconView.imageView sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
    [headerView addSubview:iconView];
    [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(85);
        make.centerX.mas_equalTo(headerView);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    
    // 点击头像上传头像或者浏览
    
    [iconView.imageButton bk_addEventHandler:^(id sender) {
        NSLog(@"点击了");
    } forControlEvents:UIControlEventTouchUpInside];
    iconView.layer.cornerRadius = 30;
    iconView.layer.masksToBounds = YES;
    UILabel *username = [[UILabel alloc] init];
    username.font = [UIFont boldSystemFontOfSize:15];
    username.textAlignment = NSTextAlignmentCenter;
    username.textColor = [UIColor whiteColor];
    [headerView addSubview:username];
    [username mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(iconView.mas_bottom).mas_equalTo(10);
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(15);
    }];
    username.text = [self.userInfo objectForKey:@"username"];
    
    UILabel *ageAndGender = [[UILabel alloc] init];
    ageAndGender.textAlignment = NSTextAlignmentCenter;
    ageAndGender.font = [UIFont boldSystemFontOfSize:13];
    ageAndGender.textColor = [UIColor whiteColor];
    [headerView addSubview:ageAndGender];
    [ageAndGender mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(username.mas_bottom).mas_equalTo(4);
        make.right.left.mas_equalTo(0);
        make.height.mas_equalTo(15);
    }];
    ageAndGender.text = [NSString stringWithFormat:@"%@ | %@",[self.userInfo objectForKey:@"gender"],[self.userInfo objectForKey:@"age"]];
    
    UILabel *desc = [[UILabel alloc] init];
    desc.textColor = [UIColor whiteColor];
    desc.textAlignment = NSTextAlignmentCenter;
    desc.font = [UIFont boldSystemFontOfSize:13];
    desc.numberOfLines = 0;
    [headerView addSubview:desc];
    [desc mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(ageAndGender.mas_bottom).mas_equalTo(4);
        make.right.mas_equalTo(-10);
        make.left.mas_equalTo(10);
        make.height.mas_equalTo(50);
    }];
    desc.text = [NSString stringWithFormat:@"简介: %@",[self.userInfo objectForKey:@"desc"]];
    
    
    return headerView;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"Cell"];
    
    switch (indexPath.row) {
        case 0:{
            if (self.mark) {
                self.mark = NO;
                [self getUserInfo];
            }
            TrendCell *tcell = [[TrendCell alloc] init];
            tcell.count.text = self.trendCount;
            tcell.title.text = self.lateTitle;
            tcell.content.text = self.lateContent;
            if (self.isHasImage) {
                [tcell.imageV sd_setImageWithURL:self.imageURL placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
            }else {
                tcell.imageV.hidden = YES;
                [tcell.title mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(10);
                    make.left.mas_equalTo(tcell.trends.mas_right).mas_equalTo(10);
                    make.right.mas_equalTo(-20);
                    make.height.mas_equalTo(30);
                }];
            }
            
            return tcell;
        }
        case 1:
            cell.textLabel.text = @"故乡";
            cell.detailTextLabel.text = [self.userInfo objectForKey:@"address"];
            break;
        case 2:
            cell.textLabel.text = @"婚姻情况";
            cell.detailTextLabel.text = [self.userInfo objectForKey:@"marriage"];
            break;
        case 3:{
            cell.textLabel.text = @"吹水时间";
            NSDate *date = self.userInfo.createdAt;
            NSInteger t = 0 - [date timeIntervalSinceNow];
            NSInteger dayTime = 3600 * 24;
            NSInteger yearTime = dayTime * 365;
            NSString *createDate = [NSString stringWithFormat:@"刚刚"];
            if (t > 60 && t < 3600) {
                createDate = [NSString stringWithFormat:@"%ld分",t/60];
            }else if (t > 3600 && t < dayTime) {
                createDate = [NSString stringWithFormat:@"%ld小时",t/3600];
            }else if (t > dayTime) {
                createDate = [NSString stringWithFormat:@"%ld天",t/dayTime];
            }else if (t > yearTime) {
                createDate = [NSString stringWithFormat:@"%ld年",t/yearTime];
            }
            cell.detailTextLabel.text = createDate;
            break;
        }
        default:
            break;
    }
    
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
        CommonListViewController *vc = [[CommonListViewController alloc] init];
        vc.coditionType = ListTypeCondition;
        vc.key = @"author";
        vc.value = self.userInfo.objectId;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return 80;
    }else {
        return 44;
    }
}


#pragma mark - 用户最新动态，以及动态的数量

- (void)getUserInfo {

        BmobQuery *bquery = [BmobQuery queryWithClassName:@"MixPost"];
        [bquery whereKey:@"author" equalTo:self.userInfo.objectId];
        [bquery countObjectsInBackgroundWithBlock:^(int number,NSError  *error){
            self.trendCount = [NSString stringWithFormat:@"%d",number];
        }];
        
        BmobQuery *post = [BmobQuery queryWithClassName:@"MixPost"];
        post.limit = 1;
        [post whereKey:@"author" equalTo:self.userInfo.objectId];
        [post orderByDescending:@"createdAt"];
        // 优先从本地缓存获取数据，假如没有数据才从网络下载
        post.cachePolicy = kBmobCachePolicyNetworkElseCache;
        // 查找数据
        [post findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            for (BmobObject *obj in array) {
                self.lateTitle = [obj objectForKey:@"title"];
                self.lateContent = [obj objectForKey:@"content"];
                NSString *imageurl = [NSString stringWithFormat:@"%@?t=1&a=b7ef3c9d216363a6245f34d0a69f8940",[obj objectForKey:@"imageUrl"]];
                self.imageURL = [NSURL URLWithString:imageurl];
                if ([obj objectForKey:@"imageUrl"] == nil) {
                    self.isHasImage = NO;
                }
            }
            [self.tableView reloadData];
            
            
        }];
    
    
}


#pragma mark - 检查是否销毁
- (void)dealloc {
    NSLog(@"UserInfoViewController 销毁了");
}



@end
