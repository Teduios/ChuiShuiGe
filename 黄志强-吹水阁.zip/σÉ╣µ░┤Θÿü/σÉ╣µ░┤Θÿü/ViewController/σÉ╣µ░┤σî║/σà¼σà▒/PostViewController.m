//
//  PostViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/13.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "PostViewController.h"

@interface PostViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>

@property (strong, nonatomic) UITextField *topic;       // 帖子的主题
@property (strong, nonatomic) UITextView *content;      // 帖子的内容
@property (strong, nonatomic) UIImageView *imageView;   // 帖子的照片
@property (strong, nonatomic) UIButton *photoBtn;       // 选择图片按钮
@property (strong, nonatomic) UIImage *image;           // 选择的图片
@property (strong, nonatomic) NSString *imageFileName;  // 上传图片后的图片名
@property (nonatomic) NSInteger mark;                   // 是否选择图片的标志
@property (nonatomic) CGFloat progress;                 // 进度
@property (strong, nonatomic) NSString *sectionType;    // 分区的类型

@end

@implementation PostViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kRGBColor(247, 247, 247);
    self.navigationItem.title = @"发表主题";
    self.mark = 1;
    self.topic.placeholder = @"这里是标题呢";
    self.content.hidden = NO;
    self.photoBtn.hidden = NO;
    self.imageView.hidden = NO;
    
    
    // 发帖按钮
    UIButton *sendBtn = [[UIButton alloc] init];
    sendBtn.backgroundColor = kColor;
    [sendBtn setTitle:@"发帖" forState:UIControlStateNormal];
    sendBtn.frame = CGRectMake(0, 0, 50, 24);
    sendBtn.layer.cornerRadius = 4;
    sendBtn.titleLabel.font = kNaviFont;
    [sendBtn addTarget:self action:@selector(sendTopicTie) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:sendBtn];
    
    
}

#pragma mark - 懒加载
- (UITextField *)topic {
    if (_topic == nil) {
        _topic = [[UITextField alloc] init];
        _topic.layer.borderWidth = 2;
        _topic.layer.cornerRadius = 15;
        _topic.layer.masksToBounds = YES;
        _topic.layer.borderColor = kColor.CGColor;
        _topic.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 30)];
        _topic.leftViewMode = UITextFieldViewModeAlways;
        _topic.rightView = self.photoBtn;
        _topic.rightViewMode = UITextFieldViewModeAlways;
        [self.view addSubview:_topic];
        [_topic mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(100);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(30);
        }];
    }
    return _topic;
}

- (UITextView *)content {
    if (_content == nil) {
        _content = [[UITextView alloc] init];
        [self.view addSubview:_content];
        _content.layer.borderWidth = 2;
        _content.layer.cornerRadius = 15;
        _content.layer.masksToBounds = YES;
        _content.layer.borderColor = kColor.CGColor;
        [_content mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(200);
            make.right.mas_equalTo(-20);
        }];
//        _content.frame = CGRectMake(0, 94, kWindowW, kWindowH - 94);
    }
    return _content;
}

- (UIImageView *)imageView {
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] init];
        _imageView.contentMode = 0;
        _imageView.backgroundColor = [UIColor brownColor];
        [self.view addSubview:_imageView];
        
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_topic.mas_bottom).mas_equalTo(5);
            make.leftMargin.mas_equalTo(_topic.mas_leftMargin);
            make.height.mas_equalTo(0);
            make.width.mas_equalTo(40);
        }];
        
        
    }
    return _imageView;
}

- (UIButton *)photoBtn {
    if (_photoBtn == nil) {
        _photoBtn = [[UIButton alloc] init];
        [_photoBtn setImage:[UIImage imageNamed:@"icon_camera"] forState:UIControlStateNormal];
        _photoBtn.frame = CGRectMake(0, 0, 40, 30);
        [_photoBtn bk_addEventHandler:^(id sender) {
            /** 选择头像的来源 相册/拍照 */
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"从相册选取" otherButtonTitles:@"拍照选取", nil];
            [actionSheet showInView:self.view];
            
            
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _photoBtn;
}


- (UIImage *)image {
    if (_image == nil) {
        _image = [[UIImage alloc] init];
    }
    return _image;
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSLog(@"buttonindex:%ld",buttonIndex);
    UIImagePickerController *pc = [[UIImagePickerController alloc] init];
    pc.delegate = self;
    // 开启编辑功能
    pc.allowsEditing = YES;
    // 可以定义要选取的数据类型，默认只显示图片
    pc.mediaTypes = @[(NSString *)kUTTypeMovie,(NSString *)kUTTypeImage];
    
    if (buttonIndex == 0) {
        [self presentViewController:pc animated:YES completion:nil];
    }else if (buttonIndex == 1) {
        // 选择输入源的类型为拍照，默认只是相册
        pc.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:pc animated:YES completion:nil];
    }else {
        return;
    }
    
}



#pragma mark - 发帖
- (void)sendTopicTie {
    [self.view endEditing:YES];
    switch (self.type) {
        case ClickTypeMix:
            self.sectionType = @"MixPost";
            break;
        case ClickTypeWomen:
            self.sectionType = @"GirlPost";
            break;
        case ClickTypeMan:
            self.sectionType = @"BoyPost";
            break;
            
        default:
            break;
    }
    
    BmobObject  *post = [BmobObject objectWithClassName:self.sectionType];
    //设置发帖人
    BmobUser *currentUser = [BmobUser getCurrentUser];
    NSString *imgFileName = [NSString stringWithFormat:@"%@.jpg",currentUser.objectId];
    NSData *data = [[NSData alloc] init];
    data = UIImagePNGRepresentation(self.image);
    if (self.topic.text.length <= 5 || self.content.text.length <= 5) {
        [self showErrorMsg:@"填多点内容再发表吧~"];
        return;
    }
    
    /** 如果没有图片 */
    if (self.mark == 1) {
        //帖子的title
        [post setObject:self.topic.text forKey:@"title"];
        //设置帖子的内容
        [post setObject:self.content.text forKey:@"content"];
        //设置帖子关联的作者记录
        BmobUser *author = [BmobUser objectWithoutDatatWithClassName:@"_User" objectId:currentUser.objectId];
        [post setObject:author forKey:@"author"];
        //异步保存
        [post saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (isSuccessful) {
                //创建成功后会返回objectId，updatedAt，createdAt等信息
                [self.navigationController popViewControllerAnimated:YES];
            } else if (error){
                //发生错误后的动作
                [self showErrorMsg:@"网络错误"];
            } else {
                [self showErrorMsg:@"网络错误"];
            }
        }];
    }else {   /** 有照片 */
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeDeterminateHorizontalBar;
        hud.labelText = @"正在发帖...";
        hud.hidden = NO;
        //上传图片文件,因为图片较大，所以图片上传成功后才上传文字内容
        [BmobProFile uploadFileWithFilename:imgFileName fileData:data block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
            if (isSuccessful) {
                
                //帖子的title
                [post setObject:self.topic.text forKey:@"title"];
                //设置帖子的内容
                [post setObject:self.content.text forKey:@"content"];
                //设置帖子的图片
                [post setObject:url forKey:@"imageUrl"];
                
                //设置帖子关联的作者记录
                BmobUser *author = [BmobUser objectWithoutDatatWithClassName:@"_User" objectId:currentUser.objectId];
                [post setObject:author forKey:@"author"];
                
                
                //异步保存
                [post saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                    if (isSuccessful) {
                        hud.hidden = YES;
                        //创建成功后会返回objectId，updatedAt，createdAt等信息
                        //打印objectId
                        NSLog(@"objectid :%@",post.objectId);
                        [self.navigationController popViewControllerAnimated:YES];
                    } else if (error){
                        //发生错误后的动作
                        hud.hidden = YES;
                        [self showErrorMsg:@"上传错误"];
                    } else {
                        hud.hidden = YES;
                        [self showErrorMsg:@"网络错误"];
                    }
                }];
            } else {
                if (error) {
                    hud.hidden = YES;
                    [self showErrorMsg:@"网络错误"];
                }
            }
        } progress:^(CGFloat progress) {
            //上传进度，此处可编写进度条逻辑
            hud.progress = progress;
        }];
    }
    
}


#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    /**
     *  通过断点来查询到info的字典属性
     */
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    self.mark = -1;
    self.imageView.image = image;
    if (image.size.width > 300) {
        CGFloat bili = image.size.height * 1.0 / image.size.width;
        CGFloat height = 300 * bili;
        self.image = [Factory imageCompressForSize:image targetSize:CGSizeMake(300, height)];
    }else {
        self.image = [Factory imageCompressForSize:image targetSize:image.size];
    }
    
    [self.imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_topic.mas_bottom).mas_equalTo(5);
        make.left.mas_equalTo(30);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(40);
    }];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}


// 点击空白位置键盘退出
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}




#pragma mark - 检查是否销毁
- (void)dealloc {
    NSLog(@"PostViewController 销毁了");
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
}


@end
