//
//  CommonDetailViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/13.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "CommonDetailViewController.h"
#import "CommentCell.h"
#import "CommentViewModel.h"
#import "LoginNavigationController.h"
#import "LoginViewController.h"
#import "UserInfoViewController.h"

@interface CommonDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) UIView *footerView;
@property (strong, nonatomic) CommentViewModel *commentVM;
@property (strong, nonatomic) UITextField *commentTF;

@property (strong, nonatomic) UIButton *commentBtn;
@property (strong, nonatomic) UIButton *likeBtn;

@end

@implementation CommonDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 头部帖子具体信息内容
    [self postContentView];
    self.navigationItem.title = @"详情";
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.footerView.hidden = NO;
    self.tableView.hidden = NO;
    [self.tableView registerClass:[CommentCell class] forCellReuseIdentifier:@"Cell"];
    
    /** 评论数据刷新 */
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [self reloadData];
    }];
    
    [self.tableView.mj_header beginRefreshing];
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [self.commentVM getMoreCommentDataWithPost:self.post CompletionHandle:^(NSError *error) {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            [self.tableView.mj_footer endRefreshing];
        }];
    }];
    
    
    
}

#pragma mark - 数据刷新
- (void)reloadData {
    [self.commentVM refreshCommentDataWithPost:self.post CompletionHandle:^(NSError *error) {
        [self.tableView.mj_header endRefreshing];
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
            [self postContentView];
        });
    }];
}

#pragma mark - 懒加载
- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        _tableView.backgroundColor = kRGBColor(247, 247, 247);
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.mas_equalTo(0);
            make.bottom.mas_equalTo(self.footerView.mas_top).mas_equalTo(0);
        }];
        
    }
    return _tableView;
}

- (CommentViewModel *)commentVM {
    if (_commentVM == nil) {
        _commentVM = [[CommentViewModel alloc] init];
        _commentVM.sectionType = self.sectionType;
    }
    return _commentVM;
}

/** 底部发表评论 */
- (UIView *)footerView {
    if (_footerView == nil) {
        _footerView = [[UIView alloc] init];
        _footerView.frame = CGRectMake(0, 0, kWindowW, 44);
        _footerView.backgroundColor = kRGBColor(247, 247, 247);
        [self.view addSubview:_footerView];
        [_footerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.mas_equalTo(0);
            make.height.mas_equalTo(44);
        }];
        
        UIButton *commentBtn = [[UIButton alloc] init];
        [commentBtn setTitle:@"评论" forState:UIControlStateNormal];
        commentBtn.titleLabel.font = kTitleFont;
        [commentBtn setTitleColor:kColor forState:UIControlStateNormal];
        [_footerView addSubview:commentBtn];
        
        self.commentTF = [[UITextField alloc] init];
        _commentTF.layer.borderWidth = 2;
        _commentTF.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 30)];
        _commentTF.leftViewMode = UITextFieldViewModeAlways;
        _commentTF.layer.borderColor = kColor.CGColor;
        [_footerView addSubview:_commentTF];
        _commentTF.layer.cornerRadius = 17;
        _commentTF.placeholder = @"吐槽一下呗";
        _commentTF.layer.masksToBounds = YES;
        [_commentTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.height.mas_equalTo(34);
            make.top.mas_equalTo(5);
            make.right.mas_equalTo(commentBtn.mas_left).mas_equalTo(0);
        }];
        
        [commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.top.bottom.mas_equalTo(0);
            make.width.mas_equalTo(60);
        }];
        
        // 发表评论
        [commentBtn bk_addEventHandler:^(id sender) {
            
            [self.view endEditing:YES];
            if ([BmobUser getCurrentUser]) {
                // 获取评论的数据
                BmobObject  *comment = [BmobObject objectWithClassName:@"Comment"];
                //添加关键词，用于检索评论
                [comment setObject:self.post.objectId forKey:@"postSoure"];
                //设置帖子关联的作者记录
                BmobUser *author = [BmobUser objectWithoutDatatWithClassName:@"_User" objectId:[BmobUser getCurrentUser].objectId];
                [comment setObject:author forKey:@"author"];
                //设置评论的内容
                NSString *content = self.commentTF.text;
                if (content.length < 1) {
                    [self showErrorMsg:@"没有填写评论内容"];
                }else {
                    [comment setObject:content forKey:@"commentContent"];
                    [comment saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                        if (isSuccessful) {
                            // 成功之后返回的数据
                            [self showSuccessMsg:@"评论成功"];
                            self.commentTF.text = @"";
                            [self reloadData];
                            [self.commentBtn setTitle:[NSString stringWithFormat:@"%ld",[self.commentVM commentCountByObject:self.post]+1] forState:UIControlStateNormal];
                        } else if (error){
                            //发生错误后的动作
                            [self showErrorMsg:@"网络错误"];
                        } else {
                            [self showErrorMsg:@"网络错误"];
                        }
                    }];
                }
            }else {
                LoginNavigationController *nav = [[LoginNavigationController alloc] initWithRootViewController:[LoginViewController new]];
                [self presentViewController:nav animated:YES completion:nil];
            }
            
            
        } forControlEvents:UIControlEventTouchUpInside];
        
        
        
        
        
        
    }
    
    return _footerView;
}

/** 头部信息具体帖子信息 */
- (void)postContentView {
    UIView *post = [[UIView alloc] init];
    NSString *titleStr = [self.commentVM titleByObject:self.post];
    CGSize titleSize = [titleStr sizeWithFont:[UIFont systemFontOfSize:18] maxW:kWindowW - 20];
    if (titleStr.length == 0) {
        titleSize = CGSizeMake(0, 0);
    }
    
    NSString *contentStr = [self.commentVM contentByObject:self.post];
    CGSize contentSize = [contentStr sizeWithFont:[UIFont systemFontOfSize:15] maxW:kWindowW - 20];
    if (contentStr.length == 0) {
        contentSize = CGSizeMake(0, 0);
    }
    
    NSInteger imageHeight = [self.commentVM imageHightByObject:self.post];
    
    
    //    post.backgroundColor = [UIColor grayColor];
    post.frame = CGRectMake(0, 0, kWindowW, titleSize.height + contentSize.height + imageHeight + 135);
    
    
    
    self.tableView.tableHeaderView = post;
    /** 用户信息栏 */
    CustomImageView *headerImage = [[CustomImageView alloc] init];
    [post addSubview:headerImage];
    [headerImage.imageButton bk_addEventHandler:^(id sender) {
        [self.view endEditing:YES];
        UserInfoViewController *userInfoVC = [[UserInfoViewController alloc] init];
        userInfoVC.hidesBottomBarWhenPushed = YES;
        userInfoVC.userInfo = self.userInfo;
        [self.navigationController pushViewController:userInfoVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    
    
    [headerImage.imageView sd_setImageWithURL:[self.commentVM iconBy:self.userInfo] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
    headerImage.layer.cornerRadius = 20;
    [headerImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(10);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    
    UILabel *username = [[UILabel alloc] init];
    [post addSubview:username];
    
    username.text = [self.commentVM userNameBy:self.userInfo];
    //    username.backgroundColor = [UIColor blueColor];
    [username mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.mas_equalTo(headerImage.mas_right).mas_equalTo(10);
        make.height.mas_equalTo(20);
        make.right.mas_equalTo(-10);
    }];
    
    /** 标题和文字内容栏 */
    UILabel *title = [[UILabel alloc] init];
    [post addSubview:title];
    title.font = kTitleFont;
    title.numberOfLines = 0;
    //    title.backgroundColor = [UIColor lightGrayColor];
    title.text = titleStr;
    
    [title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(headerImage.mas_bottom).mas_equalTo(10);
        make.left.mas_equalTo(10);
        make.height.mas_equalTo(titleSize.height);
        make.right.mas_equalTo(-10);
    }];
    
    UILabel *content = [[UILabel alloc] init];
    [post addSubview:content];
    content.font = kContentFont;
    //    content.backgroundColor = [UIColor greenColor];
    content.text = contentStr;
    content.numberOfLines = 0;
    [content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(title.mas_bottom).mas_equalTo(10);
        make.left.mas_equalTo(10);
        make.height.mas_equalTo(contentSize.height);
        make.right.mas_equalTo(-10);
    }];
    
    
    /** 图片 */
    UIView *allImagesView = [[UIView alloc] init];
    [post addSubview:allImagesView];
    [allImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.top.mas_equalTo(content.mas_bottom).mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(imageHeight);
    }];
    
    /** 目前就一张照片。。。 */
    CustomImageView *imageContent = [[CustomImageView alloc] init];
    [imageContent.imageView sd_setImageWithURL:[self.commentVM allImagesByObject:self.post][0] placeholderImage:[UIImage imageNamed:@"im_img_placeholder"]];
    [allImagesView addSubview:imageContent];
    [imageContent mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    
    /** 点赞评论统计区 */
    // 发表的时间
    UILabel *date = [[UILabel alloc] init];
    [post addSubview:date];
    date.font = kCommentFont;
    date.textColor = [UIColor grayColor];
    date.text = [self.commentVM dateByObject:self.post];
    [date mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.bottom.mas_equalTo(-10);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(120);
    }];
    
    // 评论
    self.commentBtn = [[UIButton alloc] init];
    _commentBtn.titleLabel.font = kCommentFont;
    [post addSubview:_commentBtn];
    [_commentBtn setImage:[UIImage imageNamed:@"qbf_chat"] forState:UIControlStateNormal];
    [_commentBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_commentBtn setTitle:[NSString stringWithFormat:@"%ld",[self.commentVM commentCountByObject:self.post]] forState:UIControlStateNormal];
    [_commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.size.mas_equalTo(CGSizeMake(80, 30));
        make.bottom.mas_equalTo(-10);
    }];
    
    // 点赞区
    self.likeBtn = [[UIButton alloc] init];
    _likeBtn.titleLabel.font = kCommentFont;
    [post addSubview:_likeBtn];
    [_likeBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_likeBtn setTitle:[NSString stringWithFormat:@"%ld",[self.commentVM likeCountByObject:self.post]] forState:UIControlStateNormal];
    [_likeBtn setImage:[UIImage imageNamed:@"qbf_like"] forState:UIControlStateNormal];
    [_likeBtn setImage:[UIImage imageNamed:@"qbf_like_copy"] forState:UIControlStateSelected];
    [_likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(_commentBtn.mas_left).mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(80, 30));
        make.bottom.mas_equalTo(-10);
    }];
    
    [_likeBtn bk_addEventHandler:^(id sender) {
        // 点击被选中，不可再点击
        _likeBtn.selected = YES;
        _likeBtn.enabled  = NO;
        if ([BmobUser getCurrentUser]) {
            NSString *sectionName = @"";
            switch (self.sectionType) {
                case ClickTypeMix: {
                    sectionName = @"MixPost";
                    break;
                }
                case ClickTypeMan: {
                    sectionName = @"BoyPost";
                    break;
                }
                case ClickTypeWomen: {
                    sectionName = @"GirlPost";
                    break;
                }
                default: {
                    break;
                }
            }
            //获取要添加关联关系的post
            BmobObject *post = [BmobObject objectWithoutDatatWithClassName:sectionName objectId:self.post.objectId];
            
            //新建relation对象
            BmobRelation *relation = [[BmobRelation alloc] init];
            [relation addObject:[BmobObject objectWithoutDatatWithClassName:@"_User" objectId:[BmobUser getCurrentUser].objectId]];
           
            //添加关联关系到likes列中
            [post addRelation:relation forKey:@"likes"];
            //异步更新obj的数据
            [post updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    [self showSuccessMsg:@"点赞成功"];
                    [_likeBtn setTitle:[NSString stringWithFormat:@"%ld",[self.commentVM likeCountByObject:self.post]+1] forState:UIControlStateSelected];
                }else{
                    [self showErrorMsg:[error description]];
                }
            }];
        }else {
            LoginNavigationController *nav = [[LoginNavigationController alloc] initWithRootViewController:[LoginViewController new]];
            [self presentViewController:nav animated:YES completion:nil];
        }
    } forControlEvents:UIControlEventTouchUpInside];
    
    
    
    
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.commentVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CommentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.userIconView.imageView sd_setImageWithURL:[self.commentVM commentUserIconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"icon_anonymous"]];
    [cell.userIconView.imageButton bk_addEventHandler:^(id sender) {
        UserInfoViewController *userInfoVC = [[UserInfoViewController alloc] init];
        userInfoVC.hidesBottomBarWhenPushed = YES;
        userInfoVC.userInfo = self.userInfo;
        [self.navigationController pushViewController:userInfoVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.username.text = [self.commentVM commentUsernameForRow:indexPath.row];
    cell.commentDate.text = [self.commentVM commentDataForRow:indexPath.row];
    cell.comment.text = [self.commentVM commentContentForRow:indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *commentusr = [self.commentVM commentUsernameForRow:indexPath.row];
    self.commentTF.text = [NSString stringWithFormat:@"回复 %@: ",commentusr];
    [self.commentTF becomeFirstResponder];
}



#pragma mark - 添加键盘监听
// 在界面即将呈现的时候，添加键盘的监听

- (void)viewWillAppear:(BOOL)animated

{
    
    [super viewWillAppear:animated];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    [center addObserver:self selector:@selector(open:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(close:) name:UIKeyboardWillHideNotification object:nil];
    
}



- (void)viewWillDisappear:(BOOL)animated

{
    
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
}





- (void)open:(NSNotification *)p
{
    CGRect keyboardFrame = [p.userInfo[UIKeyboardFrameEndUserInfoKey]CGRectValue];
    
    [self.footerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(44);
        make.bottom.mas_equalTo(0 - keyboardFrame.size.height);
    }];
    
    NSInteger option = [p.userInfo[UIKeyboardAnimationCurveUserInfoKey]intValue];
    
    NSInteger duration = [p.userInfo[UIKeyboardAnimationDurationUserInfoKey]intValue];
    
    [UIView animateKeyframesWithDuration:duration delay:0 options:option animations:^{
        
        [self.view layoutIfNeeded];
        
    } completion:nil];
    
    
    
}

- (void)close:(NSNotification *)c

{
    
    [self.footerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.height.mas_equalTo(44);
    }];
    
    NSInteger option = [c.userInfo[UIKeyboardAnimationCurveUserInfoKey]intValue];
    
    NSInteger duration = [c.userInfo[UIKeyboardAnimationDurationUserInfoKey]intValue];
    
    [UIView animateKeyframesWithDuration:duration delay:0 options:option animations:^{
        
        [self.view layoutIfNeeded];
        
    } completion:nil];
    
}




@end
