//
//  MainTabBarViewController.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "MainTabBarViewController.h"
#import "FreeChatViewController.h"
#import "LookWorldViewController.h"
#import "ChatViewController.h"
#import "PofileViewController.h"
#import "BaseNavigationController.h"

@interface MainTabBarViewController ()

@end

@implementation MainTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /** 吹水区控制器 */
    FreeChatViewController *mainVC = [[FreeChatViewController alloc] init];
    [self setChildVC:mainVC andTitle:@"吹水区" andNormalImage:@"icon_justbb_f" andSelectedImage:@"icon_justbb_yel"];
    /** 看世界控制器 */
    LookWorldViewController *friendVC = [[LookWorldViewController alloc] initWithPageNew];
    [self setChildVC:friendVC andTitle:@"看世界" andNormalImage:@"icon_watchworld_f" andSelectedImage:@"icon_watchworld_yel"];
    /** 聊天控制器 */
//    ChatViewController *discoverVC = [[ChatViewController alloc] init];
//    [self setChildVC:discoverVC andTitle:@"聊天" andNormalImage:@"icon_chat" andSelectedImage:@"icon_chat_active"];
    /** 我的控制器 */
    PofileViewController *meVC = [[PofileViewController alloc] init];
    [self setChildVC:meVC andTitle:@"我" andNormalImage:@"icon_me_f" andSelectedImage:@"icon_me_yel"];
    
}


/**
 *  用来设置tabbar子控制器的样式
 *
 *  @param vc            传入的控制器
 *  @param title         tabBarItem的title
 *  @param normalImage   tabBarItem的正常图片
 *  @param selectedImage tabBarItem中的被选中时的图片
 */
- (void)setChildVC:(UIViewController *)vc andTitle:(NSString *)title andNormalImage:(NSString *)normalImage andSelectedImage:(NSString *)selectedImage {
    [vc.tabBarItem setImage:[[UIImage imageNamed:normalImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.title = title;
    NSMutableDictionary *textNormalAtt = [NSMutableDictionary dictionary];
    NSMutableDictionary *textSelectedAtt = [NSMutableDictionary dictionary];
    textSelectedAtt[NSForegroundColorAttributeName] = kRGBColor(255, 160, 21);
    [vc.tabBarItem setTitleTextAttributes:textNormalAtt forState:UIControlStateNormal];
    [vc.tabBarItem setTitleTextAttributes:textSelectedAtt forState:UIControlStateSelected];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:vc];
    [self addChildViewController:nav];
    
}

+ (void)initialize
{
    
}


@end
