//
//  AppDelegate.m
//  吹水阁
//
//  Created by apple-jd35 on 15/11/12.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "MainTabBarViewController.h"
#import "NewsNetworkManager.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

//   7559825d0d0d43f9033c73042dcd8ccf
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    /** 注册Bmob */
    [Bmob registerWithAppKey:@"7559825d0d0d43f9033c73042dcd8ccf"];
   
    MainTabBarViewController *vc = [[MainTabBarViewController alloc] init];
    self.window.rootViewController = vc;
    return YES;
}


#pragma mark - 懒加载
- (UIWindow *)window {
    if (_window == nil) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _window.backgroundColor = [UIColor whiteColor];
        [_window makeKeyAndVisible];
    }
    return _window;
}




@end
